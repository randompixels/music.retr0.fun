---
title: "Rage Against The Machine — Rage Against The Machine"
date: 2017-06-05T13:56:07+00:00 
draft: false
year: "1992, Reissued 2012"
artist: "Rage Against The Machine"
album_name: "Rage Against The Machine"
format: "LP"
video: "wauzrPn0cfg"
cover: "/uploads/2017/06/IMG_0182-1024x1024.jpg"
images: ["/uploads/2017/06/IMG_0183.jpg", "/uploads/2017/06/IMG_0184.jpg", "/uploads/2017/06/IMG_0181-1.jpg"]
---
