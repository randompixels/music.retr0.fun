---
title: "Yarah Bravo — Love Is The Movement"
date: 2019-06-12T14:10:48+00:00 
draft: false
year: "2014"
artist: "Yarah Bravo"
album_name: "Love Is The Movement"
format: "LP"
video: "Eseb1aDJM"
cover: "/uploads/2019/06/IMG_7413.jpg"
images: ["/uploads/2019/06/IMG_7414.jpg", "/uploads/2019/06/IMG_7443.jpg", "/uploads/2019/06/IMG_7444.jpg"]
---
