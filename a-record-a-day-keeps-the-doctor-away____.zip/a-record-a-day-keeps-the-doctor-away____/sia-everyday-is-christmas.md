---
title: "Sia — Everyday Is Christmas"
date: 2018-12-25T21:07:47+00:00 
draft: false
year: "2017"
artist: "Sia"
album_name: "Everyday Is Christmas"
format: "LP"
video: "MGanJGGVSrw"
cover: "/uploads/2018/12/IMG_1858.jpg"
images: ["/uploads/2018/12/IMG_1859.jpg", "/uploads/2018/12/IMG_1861.jpg", "/uploads/2018/12/IMG_1857.jpg"]
---
