---
title: "Gotan Project — La Revancha Del Tango"
date: 2019-06-08T12:22:40+00:00 
draft: false
year: "2001 (Reissued 2016)"
artist: "Gotan Project"
album_name: "La Revancha Del Tango"
format: "2xLP, Red"
video: "Vbh-jn8V54c"
cover: "/uploads/2019/06/IMG_7318-1024x1024.jpg"
images: ["/uploads/2019/06/IMG_7339.jpg", "/uploads/2019/06/IMG_7320.jpg", "/uploads/2019/06/IMG_7321.jpg", "/uploads/2019/06/IMG_7340.jpg", "/uploads/2019/06/IMG_7319.jpg"]
---
