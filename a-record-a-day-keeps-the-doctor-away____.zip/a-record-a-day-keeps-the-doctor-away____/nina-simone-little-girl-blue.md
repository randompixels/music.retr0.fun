---
title: "Nina Simone — Little Girl Blue"
date: 2018-02-27T18:58:39+00:00 
draft: false
year: "1958 (Reissued 2016)"
artist: "Nina Simone"
album_name: "Little Girl Blue"
format: "LP, Blue"
video: "cIx8B9qirAw"
cover: "/uploads/2018/02/IMG_3618-1024x1024.jpg"
images: ["/uploads/2018/02/IMG_3619.jpg", "/uploads/2018/02/IMG_3621.jpg", "/uploads/2018/02/IMG_3622.jpg"]
---
