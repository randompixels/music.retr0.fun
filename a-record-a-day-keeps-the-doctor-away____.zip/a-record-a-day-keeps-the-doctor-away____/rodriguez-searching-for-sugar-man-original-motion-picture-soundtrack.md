---
title: "Sixto Rodriguez — Searching For Sugar Man (Soundtrack)"
date: 2018-10-14T09:15:31+00:00 
draft: false
year: ""
artist: "Sixto Rodriguez"
album_name: "Searching For Sugar Man (Soundtrack)"
format: "2xLP, Limited Edition (500), Gold "
video: "E90_aL870ao"
cover: "/uploads/2018/10/IMG_0646.jpg"
images: ["/uploads/2018/10/IMG_0644.jpg", "/uploads/2018/10/IMG_0647.jpg", "/uploads/2018/10/IMG_0650.jpg", "/uploads/2018/10/IMG_0645.jpg", "/uploads/2018/10/IMG_0648.jpg"]
---
