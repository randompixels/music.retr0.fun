---
title: "N.W.A. — Straight Outta Compton"
date: 2018-02-15T08:12:20+00:00 
draft: false
year: "1988 (Reissued 2013)"
artist: "N.W.A."
album_name: "Straight Outta Compton"
format: "LP"
video: "kIJeJK0iZDE"
cover: "/uploads/2018/02/IMG_3191-1024x1024.jpg"
images: ["/uploads/2018/02/IMG_3189.jpg", "/uploads/2018/02/IMG_3190.jpg", "/uploads/2018/02/IMG_3192.jpg"]
---
