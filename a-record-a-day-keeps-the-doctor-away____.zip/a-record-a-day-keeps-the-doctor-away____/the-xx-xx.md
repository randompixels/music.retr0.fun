---
title: "The XX — xx"
date: 2018-01-26T16:21:50+00:00 
draft: false
year: "2009"
artist: "The XX"
album_name: "xx"
format: "LP"
video: "_VPKfacgXao"
cover: "/uploads/2018/01/IMG_2807-1024x1024.jpg"
images: ["/uploads/2018/01/IMG_2802.jpg", "/uploads/2018/01/IMG_2804.jpg", "/uploads/2018/01/IMG_2805.jpg"]
---
