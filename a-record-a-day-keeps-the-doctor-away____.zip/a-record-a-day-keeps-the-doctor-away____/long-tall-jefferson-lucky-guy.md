---
title: "Long Tall Jefferson – Lucky Guy"
date: 2019-06-14T13:39:56+03:00
lastmod: 2019-06-14T13:39:56+03:00
draft: false
year: "2018"
artist: "Long Tall Jefferson"
album_name: "Lucky Guy"
format: "LP"
video: "ZrGA6ElJnec"
cover: "/uploads/2019/IMG_7410.JPG"
images: ['/uploads/2019/IMG_7412.JPG', '/uploads/2019/IMG_7452.JPG', '/uploads/2019/IMG_7454.JPG', '/uploads/2019/IMG_7406.JPG']
---
