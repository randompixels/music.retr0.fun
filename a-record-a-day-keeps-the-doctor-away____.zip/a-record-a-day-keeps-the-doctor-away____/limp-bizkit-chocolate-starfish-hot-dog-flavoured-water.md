---
title: "Limp Bizkit — Chocolate Starfish And The Hot Dog Flavoured Water"
date: 2017-05-25T12:57:17+00:00 
draft: false
year: "2000"
artist: "Limp Bizkit"
album_name: "Chocolate Starfish And The Hot Dog Flavoured Water"
format: "2xLP, Gatefold"
video: "BE9CXWV1alg"
cover: "/uploads/2017/05/IMG_0004-1024x1024.jpg"
images: ["/uploads/2017/05/IMG_0005-1.jpg", "/uploads/2017/05/IMG_0016.jpg", "/uploads/2017/05/IMG_0006.jpg"]
---
