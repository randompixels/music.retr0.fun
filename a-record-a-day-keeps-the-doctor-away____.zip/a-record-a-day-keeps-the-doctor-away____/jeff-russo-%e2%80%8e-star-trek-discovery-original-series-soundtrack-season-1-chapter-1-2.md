---
title: "Jeff Russo — Star Trek: Discovery - Season 1 (Soundtrack)"
date: 2018-12-19T11:04:44+00:00 
draft: false
year: "2018"
artist: "Jeff Russo"
album_name: "Star Trek: Discovery - Season 1 (Soundtrack)"
format: "2xLP, Limited Edition, Intergalactic Starburst"
video: "H0MFmhCS08A"
cover: "/uploads/2018/12/IMG_1514.jpg"
images: ["/uploads/2018/12/IMG_1528.jpg", "/uploads/2018/12/IMG_1515.jpg", "/uploads/2018/12/IMG_1524.jpg", "/uploads/2018/12/IMG_1525.jpg", "/uploads/2018/12/IMG_1523.jpg", "/uploads/2018/12/xIMG_1519.jpg"]
---
