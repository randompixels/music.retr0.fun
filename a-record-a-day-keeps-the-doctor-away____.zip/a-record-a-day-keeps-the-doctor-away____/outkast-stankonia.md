---
title: "OutKast — Stankonia"
date: 2017-05-28T10:18:22+00:00 
draft: false
year: "2000, Reissued in 2016"
artist: "OutKast"
album_name: "Stankonia"
format: "2xLP"
video: "MYxAiK6VnXw"
cover: "/uploads/2017/05/IMG_0049-1024x1024.jpg"
images: ["/uploads/2017/05/IMG_0050.jpg", "/uploads/2017/05/IMG_0052-1.jpg", "/uploads/2017/05/IMG_0051.jpg"]
---
