---
title: "Gogol Bordello — Live From Axis Mundi"
date: 2018-09-13T09:16:36+00:00 
draft: false
year: "2009"
artist: "Gogol Bordello"
album_name: "Live From Axis Mundi"
format: "2xLP, DVD"
video: "PeBqQZbg3i0"
cover: "/uploads/2018/09/IMG_9535.jpg"
images: ["/uploads/2018/09/IMG_9540.jpg", "/uploads/2018/09/IMG_9537.jpg", "/uploads/2018/09/IMG_9538.jpg", "/uploads/2018/09/IMG_9539.jpg", "/uploads/2018/09/IMG_9536.jpg"]
---
