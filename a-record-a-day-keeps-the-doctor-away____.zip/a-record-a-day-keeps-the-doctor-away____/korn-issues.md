---
title: "Korn — Issues"
date: 2017-07-07T09:08:18+00:00 
draft: false
year: "1999, Reissued 2010"
artist: "Korn"
album_name: "Issues"
format: "2xLP"
video: "2s3iGpDqQpQ"
cover: "/uploads/2017/07/IMG_1039-1024x1024.jpg"
images: ["/uploads/2017/07/IMG_1041.jpg", "/uploads/2017/07/IMG_1042-1.jpg", "/uploads/2017/07/IMG_1040-1.jpg"]
---
