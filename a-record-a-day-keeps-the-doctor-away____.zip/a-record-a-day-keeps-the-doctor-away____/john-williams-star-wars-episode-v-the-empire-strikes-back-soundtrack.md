---
title: "John Williams — Star Wars - Episode V: The Empire Strikes Back (Soundtrack)"
date: 2018-04-01T09:28:38+00:00 
draft: false
year: "1980 (Reissued 2016)"
artist: "John Williams"
album_name: "Star Wars - Episode V: The Empire Strikes Back (Soundtrack)"
format: "2xLP, Gold"
video: "cuJhRe7x0fc"
cover: "/uploads/2018/03/IMG_4356.jpg"
images: ["/uploads/2018/03/IMG_4355.jpg", "/uploads/2018/03/IMG_4358.jpg", "/uploads/2018/03/IMG_4359.jpg", "/uploads/2018/03/IMG_4360.jpg", "/uploads/2018/03/IMG_4361.jpg", "/uploads/2018/03/IMG_4362.jpg"]
---
