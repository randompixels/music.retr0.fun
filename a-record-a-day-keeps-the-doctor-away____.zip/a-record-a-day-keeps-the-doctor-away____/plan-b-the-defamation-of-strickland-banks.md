---
title: "Plan B — The Defamation Of Strickland Banks"
date: 2018-02-12T09:48:36+00:00 
draft: false
year: "2010"
artist: "Plan B"
album_name: "The Defamation Of Strickland Banks"
format: "2xLP"
video: "axfD-IqmTZg"
cover: "/uploads/2018/02/IMG_3135-1024x1024.jpg"
images: ["/uploads/2018/02/IMG_3133.jpg", "/uploads/2018/02/IMG_3136.jpg", "/uploads/2018/02/IMG_3137.jpg"]
---
