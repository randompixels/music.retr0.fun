---
title: "Madvillain — Madvillainy"
date: 2018-01-23T20:59:47+00:00 
draft: false
year: "2004"
artist: "Madvillain"
album_name: "Madvillainy"
format: "2xLP"
video: "g8QS7wyLLiw"
cover: "/uploads/2018/01/IMG_2636-1024x1024.jpg"
images: ["/uploads/2018/01/IMG_2634.jpg", "/uploads/2018/01/IMG_2637.jpg", "/uploads/2018/01/IMG_2635.jpg"]
---
