---
title: "Dido — No Angel"
date: 2018-08-03T11:28:30+00:00 
draft: false
year: "1999 (Reissued 2018)"
artist: "Dido"
album_name: "No Angel"
format: "LP, Limited Edition of 1500, Red/Black Split"
video: "1TO48Cnl66w"
cover: "/uploads/2018/08/IMG_7854.jpg"
images: ["/uploads/2018/08/IMG_7863.jpg", "/uploads/2018/08/IMG_7856.jpg", "/uploads/2018/08/IMG_7858.jpg"]
---
