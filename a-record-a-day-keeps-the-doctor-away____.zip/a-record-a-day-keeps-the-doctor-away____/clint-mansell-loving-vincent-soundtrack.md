---
title: "Clint Mansell — Loving Vincent (Soundtrack)"
date: 2018-09-06T06:13:56+00:00 
draft: false
year: "2017"
artist: "Clint Mansell"
album_name: "Loving Vincent (Soundtrack)"
format: "LP, Yellow"
video: "kJ8sg9akQNI"
cover: "/uploads/2018/09/IMG_9236.jpg"
images: ["/uploads/2018/09/IMG_9231.jpg", "/uploads/2018/09/IMG_9234.jpg", "/uploads/2018/09/IMG_9235.jpg", "/uploads/2018/09/IMG_9233.jpg"]
---
