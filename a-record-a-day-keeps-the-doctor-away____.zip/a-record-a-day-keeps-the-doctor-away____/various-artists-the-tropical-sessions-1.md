---
title: "Various Artists — The Tropical Sessions #1"
date: 2018-03-12T14:48:51+00:00 
draft: false
year: "2015"
artist: "Various Artists"
album_name: "The Tropical Sessions #1"
format: "4xLP"
video: "XK33xMbdWcQ"
cover: "/uploads/2018/03/IMG_3847.jpg"
images: ["/uploads/2018/03/IMG_3848.jpg", "/uploads/2018/03/IMG_3850-2.jpg", "/uploads/2018/03/IMG_3849.jpg"]
---
