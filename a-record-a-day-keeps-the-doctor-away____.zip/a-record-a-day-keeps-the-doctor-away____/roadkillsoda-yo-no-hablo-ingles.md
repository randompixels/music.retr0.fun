---
title: "RoadKillSoda — Yo No Hablo Ingles"
date: 2019-01-24T18:23:11+00:00 
draft: false
year: "2014"
artist: "RoadKillSoda"
album_name: "Yo No Hablo Ingles"
format: "2xLP"
video: "3eRfcjgAWlE"
cover: "/uploads/2019/01/IMG_2723.jpg"
images: ["/uploads/2019/01/IMG_2724.jpg", "/uploads/2019/01/IMG_2725.jpg", "/uploads/2019/01/IMG_2726.jpg", "/uploads/2019/01/IMG_2729.jpg"]
---
