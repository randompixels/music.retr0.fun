---
title: "Oscar and the Wolf – Infinity"
date: 2019-06-23T19:10:51+03:00
lastmod: 2019-06-23T19:10:51+03:00
draft: false
year: "2017"
artist: "Oscar and the Wolf"
album_name: "Infinity"
format: "2xLP, Limited Edition, Pink"
video: "duBW5pCIFgg" 
cover: "/uploads/2019/IMG_7583.JPG"
images: ['/uploads/2019/IMG_7582.JPG', '/uploads/2019/IMG_7336.JPG', '/uploads/2019/IMG_7586.JPG', '/uploads/2019/IMG_7337.JPG', '/uploads/2019/IMG_7351.JPG', '/uploads/2019/IMG_7352.JPG', '/uploads/2019/IMG_7331.JPG']
---
