---
title: "The Cranberries — No Need To Argue"
date: 2018-07-08T18:51:48+00:00 
draft: false
year: "1994 (Reissued 2018)"
artist: "The Cranberries"
album_name: "No Need To Argue"
format: "LP, Limited Edition of 1500, Reissue, White "
video: "u9xBd63USwY"
cover: "/uploads/2018/07/IMG_7424.jpg"
images: ["/uploads/2018/07/IMG_7422.jpg", "/uploads/2018/07/IMG_7415.jpg", "/uploads/2018/07/IMG_7425.jpg", "/uploads/2018/07/IMG_7410.jpg", "/uploads/2018/07/IMG_7417.jpg"]
---
