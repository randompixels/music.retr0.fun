---
title: "The Prodigy — Invaders Must Die"
date: 2018-02-03T10:49:12+00:00 
draft: false
year: "2009"
artist: "The Prodigy"
album_name: "Invaders Must Die"
format: "5xOrange 7\", 2xCD, DVD"
video: "voBNpdXkLnU"
cover: "/uploads/2018/02/IMG_2968-1024x1024.jpg"
images: ["/uploads/2018/02/IMG_2969.jpg", "/uploads/2018/02/IMG_2975.jpg", "/uploads/2018/02/IMG_2977.jpg"]
---
