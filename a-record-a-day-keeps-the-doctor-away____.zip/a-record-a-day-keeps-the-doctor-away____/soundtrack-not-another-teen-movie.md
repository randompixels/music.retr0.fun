---
title: "Soundtrack — Not Another Teen Movie"
date: 2018-08-02T09:35:59+00:00 
draft: false
year: "2017"
artist: "Soundtrack"
album_name: "Not Another Teen Movie"
format: "LP, Limited Edition of 500, Numbered, no. 273, \"John Hughes High\" Swirl"
video: "aJZTfl3DmCU"
cover: "/uploads/2018/08/IMG_7815-1024x1024.jpg"
images: ["/uploads/2018/08/IMG_7816.jpg", "/uploads/2018/08/IMG_7819.jpg", "/uploads/2018/08/IMG_7820.jpg"]
---
