---
title: "David Bowie — Nothing Has Changed <small>(The Very Best Of Bowie)</small>"
date: 2017-03-27T06:28:58+00:00 
draft: false
year: "2014"
artist: "David Bowie"
album_name: "Nothing Has Changed <small>(The Very Best Of Bowie)</small>"
format: "2xLP, Gatefold"
video: "sI66hcu9fIs"
cover: "/uploads/2017/03/IMG_8474-e1490596195505-1024x1024.jpg"
images: ["/uploads/2017/03/IMG_8475-e1490596040618.jpg", "/uploads/2017/03/IMG_8478-e1490596344271.jpg", "/uploads/2017/03/IMG_8473-1.jpg"]
---
