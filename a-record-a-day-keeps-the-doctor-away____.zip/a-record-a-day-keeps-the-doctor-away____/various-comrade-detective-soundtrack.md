---
title: "Various — Comrade Detective (Soundtrack)"
date: 2019-05-04T11:36:50+00:00 
draft: false
year: "2018"
artist: "Various"
album_name: "Comrade Detective (Soundtrack)"
format: "LP, Limited Edition"
video: "19UGAVxoIao"
cover: "/uploads/2019/05/IMG_6532.jpg"
images: ["/uploads/2019/05/IMG_6531.jpg", "/uploads/2019/05/IMG_6534.jpg", "/uploads/2019/05/IMG_6529.jpg"]
---
