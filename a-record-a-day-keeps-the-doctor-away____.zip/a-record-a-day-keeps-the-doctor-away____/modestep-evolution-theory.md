---
title: "Modestep — Evolution Theory"
date: 2017-07-20T16:54:48+00:00 
draft: false
year: "2013"
artist: "Modestep"
album_name: "Evolution Theory"
format: "2xLP, Gatefold, Yellow"
video: "uekJ_BQAnmM"
cover: "/uploads/2017/07/IMG_1271-1024x1024.jpg"
images: ["/uploads/2017/07/IMG_1266.jpg", "/uploads/2017/07/IMG_1267-1.jpg", "/uploads/2017/07/IMG_1270.jpg"]
---
