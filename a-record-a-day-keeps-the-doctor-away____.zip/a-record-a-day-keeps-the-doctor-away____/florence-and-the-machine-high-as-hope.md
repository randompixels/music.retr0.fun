---
title: "Florence And The Machine — High As Hope"
date: 2018-08-01T12:47:56+00:00 
draft: false
year: "2018"
artist: "Florence And The Machine"
album_name: "High As Hope"
format: "LP, Yello, Limited Edition"
video: "5GHXEGz3PJg"
cover: "/uploads/2018/08/IMG_7805-1.jpg"
images: ["/uploads/2018/08/IMG_7806-1.jpg", "/uploads/2018/08/IMG_7807.jpg", "/uploads/2018/08/IMG_7804.jpg"]
---
