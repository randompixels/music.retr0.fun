---
title: "Ленинград — Leningrad Band"
date: 2018-09-26T08:08:45+00:00 
draft: false
year: "2017"
artist: "Ленинград"
album_name: "Leningrad Band"
format: "Box, Limited Edition, Numbered, 51, 6×Vinyl, LP, Album, Limited Edition, Colored"
video: ""
cover: "/uploads/2018/09/IMG_0001-1024x1024.jpg"
images: ["/uploads/2018/09/IMG_1511b.jpg", "/uploads/2018/09/IMG_0004.jpg", "/uploads/2018/09/IMG_0000.jpg", "/uploads/2018/09/IMG_0002.jpg", "/uploads/2018/09/IMG_0007.jpg", "/uploads/2018/09/IMG_0008.jpg", "/uploads/2018/09/IMG_0005.jpg", "/uploads/2018/09/IMG_0018.jpg", "/uploads/2018/09/IMG_0019.jpg", "/uploads/2018/09/IMG_0045.jpg", "/uploads/2018/09/IMG_0009.jpg", "/uploads/2018/09/IMG_0010.jpg", "/uploads/2018/09/IMG_0047.jpg", "/uploads/2018/09/IMG_0011.jpg", "/uploads/2018/09/IMG_0012.jpg", "/uploads/2018/09/IMG_0049.jpg", "/uploads/2018/09/IMG_0014.jpg", "/uploads/2018/09/IMG_0015.jpg", "/uploads/2018/09/IMG_0084.jpg", "/uploads/2018/09/IMG_1528.jpg", "/uploads/2018/09/IMG_0003.jpg"]
---
