---
title: "Various — 50th Anniversary Star Trek (TV Series Soundtracks)"
date: 2018-09-03T08:51:01+00:00 
draft: false
year: "2016 (Reissued 2018)"
artist: "Various"
album_name: "50th Anniversary Star Trek (TV Series Soundtracks)"
format: "2xLP, Blue Translucent with Black Smoke. Record Store Day 2018 Edition."
video: ""
cover: "/uploads/2018/09/IMG_9156-1024x1024.jpg"
images: ["/uploads/2018/09/IMG_9157.jpg", "/uploads/2018/09/IMG_9152.jpg", "/uploads/2018/09/IMG_9155.jpg"]
---
