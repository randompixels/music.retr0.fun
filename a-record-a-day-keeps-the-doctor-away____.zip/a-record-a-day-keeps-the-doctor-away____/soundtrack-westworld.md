---
title: "Ramin Djawadi — Westworld (Soundtrack)"
date: 2017-05-05T13:01:37+00:00 
draft: false
year: "2016"
artist: "Ramin Djawadi"
album_name: "Westworld (Soundtrack)"
format: "LP, Blood Red"
video: "sB2CcWDa80o"
cover: "/uploads/2017/05/IMG_9576-1024x1024.jpg"
images: ["/uploads/2017/05/IMG_9573.jpg", "/uploads/2017/05/IMG_9577-2.jpg", "/uploads/2017/05/IMG_9575.jpg"]
---
