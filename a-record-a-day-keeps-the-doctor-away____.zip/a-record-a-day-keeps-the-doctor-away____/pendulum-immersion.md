---
title: "Pendulum — Immersion"
date: 2017-05-03T12:14:56+00:00 
draft: false
year: "2010"
artist: "Pendulum"
album_name: "Immersion"
format: "2LP, Boxset, Limited"
video: "ogMNV33AhCY"
cover: "/uploads/2017/05/IMG_9472-1024x1024.jpg"
images: ["/uploads/2017/05/IMG_9473-1.jpg", "/uploads/2017/05/IMG_9471.jpg", "/uploads/2017/05/IMG_9474.jpg"]
---
