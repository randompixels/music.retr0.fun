---
title: "Elaine Paige — Stages"
date: 2018-02-28T12:52:27+00:00 
draft: false
year: "1983"
artist: "Elaine Paige"
album_name: "Stages"
format: "LP"
video: "Wvt9wMuv7LA"
cover: "/uploads/2018/02/IMG_3637-1024x1024.jpg"
images: ["/uploads/2018/02/IMG_3638.jpg", "/uploads/2018/02/IMG_3640.jpg", "/uploads/2018/02/IMG_3636.jpg"]
---
