---
title: "Nine Inch Nails — The Slip"
date: 2017-04-25T15:16:41+00:00 
draft: false
year: "2008"
artist: "Nine Inch Nails"
album_name: "The Slip"
format: "LP"
video: "MtJBOlOX6GY"
cover: "/uploads/2017/04/IMG_9314-1024x1024.jpg"
images: ["/uploads/2017/04/IMG_9317-1.jpg", "/uploads/2017/04/IMG_9315.jpg", "/uploads/2017/04/IMG_9316-1-e1493133488655.jpg"]
---
