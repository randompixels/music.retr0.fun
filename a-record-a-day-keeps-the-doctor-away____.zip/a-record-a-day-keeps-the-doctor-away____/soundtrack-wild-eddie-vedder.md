---
title: "Eddie Vedder — Into The Wild (Soundtrack)"
date: 2017-05-24T16:51:06+00:00 
draft: false
year: "2007, Reissued in 2010"
artist: "Eddie Vedder"
album_name: "Into The Wild (Soundtrack)"
format: "LP, Gatefold"
video: "lm8oxC24QZc"
cover: "/uploads/2017/05/IMG_9996-2-1024x1024.jpg"
images: ["/uploads/2017/05/IMG_9997.jpg", "/uploads/2017/05/IMG_9998-1.jpg", "/uploads/2017/05/IMG_9999-2.jpg"]
---
