---
title: "Kyle Dixon & Michael Stein — Stranger Things - Season One - Volume One (Soundtrack)"
date: 2017-04-20T07:19:41+00:00 
draft: false
year: "2016"
artist: "Kyle Dixon & Michael Stein"
album_name: "Stranger Things - Season One - Volume One (Soundtrack)"
format: "2xLP, Gatefold, Aquamarine With White And Black Splatter"
video: "ZGN9P_WTjgE"
cover: "/uploads/2017/04/IMG_9201-1024x1024.jpg"
images: ["/uploads/2017/04/IMG_9207.jpg", "/uploads/2017/04/FullSizeRender-6.jpg", "/uploads/2017/04/IMG_9202.jpg"]
---
