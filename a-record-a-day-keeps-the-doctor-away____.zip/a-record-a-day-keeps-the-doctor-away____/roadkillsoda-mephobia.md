---
title: "RoadKillSoda — Mephobia"
date: 2019-01-31T10:29:57+00:00 
draft: false
year: "2017"
artist: "RoadKillSoda"
album_name: "Mephobia"
format: "2xLP, Red"
video: "J6jbfG4aQyU"
cover: "/uploads/2019/01/IMG_2731.jpg"
images: ["/uploads/2019/01/IMG_2735.jpg", "/uploads/2019/01/IMG_2730.jpg", "/uploads/2019/01/IMG_2733.jpg", "/uploads/2019/01/IMG_2736.jpg", "/uploads/2019/01/IMG_2734-double.jpg"]
---
