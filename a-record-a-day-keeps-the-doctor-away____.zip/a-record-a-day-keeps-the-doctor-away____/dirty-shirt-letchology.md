---
title: "Dirty Shirt – Letchology"
date: 2019-06-22T18:20:54+03:00
lastmod: 2019-06-22T18:20:54+03:00
draft: false
year: "2019"
artist: "Dirty Shirt"
album_name: "Letchology"
format: "LP"
video: "uQ0GRwGVAP8?t=1350"
cover: "/uploads/2019/IMG_7418.JPG"
images: ['/uploads/2019/IMG_7419.JPG', '/uploads/2019/IMG_7446.JPG', '/uploads/2019/IMG_7580.JPG']
---
