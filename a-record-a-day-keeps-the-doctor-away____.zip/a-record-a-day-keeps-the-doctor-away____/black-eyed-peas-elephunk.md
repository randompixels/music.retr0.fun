---
title: "Black Eyed Peas — Elephunk"
date: 2017-04-21T16:50:59+00:00 
draft: false
year: "2003, Repress"
artist: "Black Eyed Peas"
album_name: "Elephunk"
format: "2xLP, Gatefold"
video: "kokvgaM4ygo"
cover: "/uploads/2017/04/FullSizeRender-9-1024x1024.jpg"
images: ["/uploads/2017/04/IMG_9238-1.jpg", "/uploads/2017/04/IMG_9243.jpg", "/uploads/2017/04/IMG_9244.jpg"]
---
