---
title: "Cristobal Tapia De Veer — Utopia (Original Television Soundtrack)"
date: 2018-03-23T10:13:38+00:00 
draft: false
year: "2014"
artist: "Cristobal Tapia De Veer"
album_name: "Utopia (Original Television Soundtrack)"
format: "2xLP, Yellow"
video: "8O8hd0S-K8k"
cover: "/uploads/2018/03/IMG_4099-1024x1024.jpg"
images: ["/uploads/2018/03/IMG_4101.jpg", "/uploads/2018/03/IMG_4103.jpg", "/uploads/2018/03/IMG_4102.jpg"]
---
