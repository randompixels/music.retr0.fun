---
title: "Various — Forza Horizon 4: Hospital (Game Soundtrack)"
date: 2018-12-24T14:24:24+00:00 
draft: false
year: "2018"
artist: "Various"
album_name: "Forza Horizon 4: Hospital (Game Soundtrack)"
format: "EP, Limited Edition, Glow-In-The-Dark"
video: "JBL5aNDudpc"
cover: "/uploads/2018/12/IMG_1790.jpg"
images: ["/uploads/2018/12/IMG_1794.gif", "/uploads/2018/12/IMG_1792.jpg", "/uploads/2018/12/IMG_1793.jpg", "/uploads/2018/12/IMG_1791.jpg", "/uploads/2018/12/IMG_1788.jpg", "/uploads/2018/12/IMG_1795.jpg"]
---
