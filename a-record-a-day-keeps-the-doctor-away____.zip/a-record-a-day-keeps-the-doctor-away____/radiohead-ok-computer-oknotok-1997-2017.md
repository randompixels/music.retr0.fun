---
title: "Radiohead — OK Computer OKNOTOK 1997 2017"
date: 2018-01-22T17:26:24+00:00 
draft: false
year: "2017"
artist: "Radiohead"
album_name: "OK Computer OKNOTOK 1997 2017"
format: "3xLP, Blue"
video: "u5CVsCnxyXg"
cover: "/uploads/2018/01/IMG_2610-1024x1024.jpg"
images: ["/uploads/2018/01/IMG_2613.jpg", "/uploads/2018/01/IMG_2615.jpg", "/uploads/2018/01/IMG_2614.jpg"]
---
