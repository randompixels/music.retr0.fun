---
title: "Nightwish — Decades - An Archive Of Song 1996-2015"
date: 2018-06-15T06:44:46+00:00 
draft: false
year: "2018"
artist: "Nightwish"
album_name: "Decades - An Archive Of Song 1996-2015"
format: "3xLP, Silver, Boxset"
video: "cBplJ7WQNVE"
cover: "/uploads/2018/06/IMG_6901-1024x1024.jpg"
images: ["/uploads/2018/06/IMG_6897.jpg", "/uploads/2018/06/IMG_6898.jpg", "/uploads/2018/06/IMG_6899.jpg", "/uploads/2018/06/IMG_6896.jpg", "/uploads/2018/06/IMG_6900.jpg"]
---
