---
title: "Morcheeba — Fragments of Freedom"
date: 2017-03-24T15:25:42+00:00 
draft: false
year: "2000"
artist: "Morcheeba"
album_name: "Fragments of Freedom"
format: "2xLP, Gatefold"
video: "Si_PAvHzjsQ"
cover: "/uploads/2017/03/IMG_8354-3-1024x1024.jpg"
images: ["/uploads/2017/03/IMG_8352-e1490369086687.jpg", "/uploads/2017/03/IMG_8356-e1490368953242.jpg", "/uploads/2017/03/IMG_8357-e1490368995472.jpg"]
---
