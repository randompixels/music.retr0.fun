---
title: "Stromae — Cheese"
date: 2019-04-10T10:33:00+00:00 
draft: false
year: "2018"
artist: "Stromae"
album_name: "Cheese"
format: "LP, Limited Edition, White"
video: "VHoT4N43jK8"
cover: "/uploads/2019/04/IMG_5735.jpg"
images: ["/uploads/2019/04/IMG_5731.jpg", "/uploads/2019/04/IMG_5736.jpg", "/uploads/2019/04/IMG_5737.jpg", "/uploads/2019/04/IMG_5733.jpg", "/uploads/2019/04/IMG_5734.jpg", "/uploads/2019/04/IMG_5730.jpg"]
---
