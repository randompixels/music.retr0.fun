---
title: "Justin Hurwitz — First Man (Soundtrack)"
date: 2019-03-20T12:05:27+00:00 
draft: false
year: "2018"
artist: "Justin Hurwitz"
album_name: "First Man (Soundtrack)"
format: "LP, Limited Edition, Lunar Surface Grey"
video: "zcev7yEPeF8"
cover: "/uploads/2019/03/IMG_4924.jpg"
images: ["/uploads/2019/03/IMG_4925.jpg", "/uploads/2019/03/IMG_4931.jpg", "/uploads/2019/03/IMG_4929.jpg", "/uploads/2019/03/IMG_4927.jpg", "/uploads/2019/03/IMG_4926-double.jpg"]
---
