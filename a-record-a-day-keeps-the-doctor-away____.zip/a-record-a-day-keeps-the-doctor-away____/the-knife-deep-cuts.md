---
title: "The Knife — Deep Cuts"
date: 2018-07-16T14:10:21+00:00 
draft: false
year: "2006 (Reissued 2013)"
artist: "The Knife"
album_name: "Deep Cuts"
format: "2xLP"
video: "pPD8Ja64mRU"
cover: "/uploads/2018/07/IMG_7588.jpg"
images: ["/uploads/2018/07/IMG_7584.jpg", "/uploads/2018/07/IMG_7587.jpg", "/uploads/2018/07/IMG_7589.jpg"]
---
