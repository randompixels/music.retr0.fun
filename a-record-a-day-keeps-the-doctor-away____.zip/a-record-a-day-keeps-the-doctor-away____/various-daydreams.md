---
title: "Various — Daydreams"
date: 2018-12-26T13:46:32+00:00 
draft: false
year: "2018"
artist: "Various"
album_name: "Daydreams"
format: "LP, Orange Clouded, Limited Edition, Numbered 488/500"
video: "8I_vzxNY8GI"
cover: "/uploads/2018/12/IMG_1874.jpg"
images: ["/uploads/2018/12/IMG_1875.jpg", "/uploads/2018/12/IMG_1872.jpg", "/uploads/2018/12/IMG_1873.jpg"]
---
