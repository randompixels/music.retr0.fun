---
title: "Adrian Younge & Ali Shaheed Muhammad — Marvel's Luke Cage - Season One (Soundtrack)"
date: 2018-07-11T11:41:38+00:00 
draft: false
year: "2016"
artist: "Adrian Younge & Ali Shaheed Muhammad"
album_name: "Marvel's Luke Cage - Season One (Soundtrack)"
format: "2xLP, Yellow"
video: ""
cover: "/uploads/2018/07/IMG_7445-1-1024x1024.jpg"
images: ["/uploads/2018/07/IMG_7449.jpg", "/uploads/2018/07/IMG_7464.jpg", "/uploads/2018/07/IMG_7448.jpg", "/uploads/2018/07/IMG_7446.jpg"]
---
