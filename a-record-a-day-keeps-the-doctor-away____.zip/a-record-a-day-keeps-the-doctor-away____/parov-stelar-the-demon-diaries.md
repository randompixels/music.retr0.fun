---
title: "Parov Stelar — The Demon Diaries"
date: 2018-05-17T08:45:13+00:00 
draft: false
year: "2015"
artist: "Parov Stelar"
album_name: "The Demon Diaries"
format: "Limited Super Deluxe Edition: 2xLP, 7\", 2xCD, Book. Limited Edition, Numbered."
video: "rgRKJHL9Yuw"
cover: "/uploads/2018/05/edit__IMG_1270.jpg"
images: ["/uploads/2018/05/edit__IMG_1286.jpg", "/uploads/2018/05/edit__IMG_1277.jpg", "/uploads/2018/05/IMG_5588.jpg", "/uploads/2018/05/edit__IMG_1273.jpg", "/uploads/2018/05/IMG_5585.jpg", "/uploads/2018/05/IMG_5590.jpg", "/uploads/2018/05/IMG_5586.jpg", "/uploads/2018/05/IMG_5591.jpg", "/uploads/2018/05/IMG_5589.jpg", "/uploads/2018/05/IMG_5592.jpg"]
---
