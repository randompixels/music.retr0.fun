---
title: "Antoine de Saint-Exupéry — Micul Prinț"
date: 2018-09-11T11:53:52+00:00 
draft: false
year: "1971"
artist: "Antoine de Saint-Exupéry"
album_name: "Micul Prinț"
format: "LP, 10\""
video: "YPpqSypmoWs"
cover: "/uploads/2018/09/IMG_9510.jpg"
images: ["/uploads/2018/09/IMG_9511.jpg", "/uploads/2018/09/IMG_9512.jpg", "/uploads/2018/09/IMG_9509.jpg"]
---
