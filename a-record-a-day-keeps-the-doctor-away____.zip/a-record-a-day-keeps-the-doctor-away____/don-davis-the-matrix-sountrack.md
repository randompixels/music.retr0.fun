---
title: "Don Davis — The Matrix (Soundtrack)"
date: 2018-01-21T14:30:11+00:00 
draft: false
year: "2012"
artist: "Don Davis"
album_name: "The Matrix (Soundtrack)"
format: "LP, Translucid Green"
video: "FExrSPevEaM"
cover: "/uploads/2018/01/IMG_2585-1024x1024.jpg"
images: ["/uploads/2018/01/IMG_2583.jpg", "/uploads/2018/01/IMG_2586.jpg", "/uploads/2018/01/IMG_2587.jpg"]
---
