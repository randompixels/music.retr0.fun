---
title: "Groove Armada — Vertigo"
date: 2018-01-28T10:27:17+00:00 
draft: false
year: "1999 (Reissued 2017)"
artist: "Groove Armada"
album_name: "Vertigo"
format: "2xLP"
video: "m-uztVX6QFQ"
cover: "/uploads/2018/01/IMG_2828-1024x1024.jpg"
images: ["/uploads/2018/01/IMG_2827-2.jpg", "/uploads/2018/01/IMG_2830.jpg", "/uploads/2018/01/IMG_2829.jpg"]
---
