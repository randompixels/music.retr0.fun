---
title: "The Complete Works — The Complete Works"
date: 2018-08-23T15:38:07+00:00 
draft: false
year: "2018"
artist: "The Complete Works"
album_name: "The Complete Works"
format: "Box Set, Limited Edition, Holographic Cover, 4 Albums (9xLP, 5xCD)"
video: ""
cover: "/uploads/2018/08/IMG_8967.jpg"
images: ["/uploads/2018/08/IMG_8966.jpg", "/uploads/2018/08/IMG_8981.jpg", "/uploads/2018/08/IMG_1402.jpg", "/uploads/2018/08/IMG_8967.jpg", "/uploads/2018/08/IMG_1377.jpg", "/uploads/2018/08/IMG_1405.jpg", "/uploads/2018/08/IMG_8968.jpg", "/uploads/2018/08/IMG_8969.jpg", "/uploads/2018/08/IMG_1384.jpg", "/uploads/2018/08/IMG_8970.jpg", "/uploads/2018/08/IMG_8971.jpg", "/uploads/2018/08/IMG_8978.jpg", "/uploads/2018/08/IMG_8973.jpg", "/uploads/2018/08/IMG_8974.jpg", "/uploads/2018/08/IMG_8979.jpg", "/uploads/2018/08/IMG_8975.jpg", "/uploads/2018/08/IMG_8976.jpg"]
---
