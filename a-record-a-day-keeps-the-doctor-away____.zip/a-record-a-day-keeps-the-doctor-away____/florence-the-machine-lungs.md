---
title: "Florence + The Machine — Lungs"
date: 2017-06-07T18:55:23+00:00 
draft: false
year: "2009"
artist: "Florence + The Machine"
album_name: "Lungs"
format: "LP, Gatefold"
video: "PQZhN65vq9E"
cover: "/uploads/2017/06/IMG_0223-1024x1024.jpg"
images: ["/uploads/2017/06/IMG_0222.jpg", "/uploads/2017/06/IMG_0221.jpg", "/uploads/2017/06/IMG_0224-1.jpg"]
---
