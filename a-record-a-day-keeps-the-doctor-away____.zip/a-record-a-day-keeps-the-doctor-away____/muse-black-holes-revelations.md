---
title: "Muse — Black Holes And Revelations"
date: 2017-05-01T12:20:44+00:00 
draft: false
year: "2015"
artist: "Muse"
album_name: "Black Holes And Revelations"
format: "LP, Reissue"
video: "D_5V8We3hgg"
cover: "/uploads/2017/05/IMG_9431-1-1024x1024.jpg"
images: ["/uploads/2017/05/IMG_9433.jpg", "/uploads/2017/05/IMG_9429.jpg", "/uploads/2017/05/IMG_9432-2.jpg"]
---
