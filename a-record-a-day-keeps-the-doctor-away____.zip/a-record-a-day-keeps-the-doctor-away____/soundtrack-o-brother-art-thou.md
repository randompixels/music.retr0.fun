---
title: "Various Artists — O Brother, Where Art Thou? (Soundtrack)"
date: 2017-05-08T16:15:46+00:00 
draft: false
year: "2015"
artist: "Various Artists"
album_name: "O Brother, Where Art Thou? (Soundtrack)"
format: "2LP, Limited, Black and White halves"
video: "wQ5BFivMwxU"
cover: "/uploads/2017/05/IMG_9611-1024x1024.jpg"
images: ["/uploads/2017/05/IMG_9615.jpg", "/uploads/2017/05/IMG_9612.jpg", "/uploads/2017/05/IMG_9614-1.jpg"]
---
