---
title: "Scandal — On A Roll"
date: 2019-01-23T09:26:22+00:00 
draft: false
year: "2018"
artist: "Scandal"
album_name: "On A Roll"
format: "LP, Limited Edition: Purple - 100, Black - 50, Yellow - 100"
video: "0e_C2SoKA4E"
cover: "/uploads/2019/01/IMG_2680.jpg"
images: ["/uploads/2019/01/IMG_2681.jpg", "/uploads/2019/01/IMG_2683.jpg", "/uploads/2019/01/IMG_2686.jpg", "/uploads/2019/01/IMG_2675.jpg", "/uploads/2019/01/IMG_2673.jpg", "/uploads/2019/01/IMG_2676.jpg", "/uploads/2019/01/IMG_2679-wide.jpg"]
---
