---
title: "Manau — Panique Celtique"
date: 2018-03-20T16:18:56+00:00 
draft: false
year: "1998"
artist: "Manau"
album_name: "Panique Celtique"
format: "LP"
video: "80hMEKlLVgQ"
cover: "/uploads/2018/03/IMG_3948-1024x1024.jpg"
images: ["/uploads/2018/03/IMG_3938-2.jpg", "/uploads/2018/03/IMG_3950.jpg", "/uploads/2018/03/IMG_3951.jpg"]
---
