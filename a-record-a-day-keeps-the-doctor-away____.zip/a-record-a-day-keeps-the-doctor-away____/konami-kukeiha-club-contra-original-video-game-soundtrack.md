---
title: "Konami Kukeiha Club — Contra (Original Video Game Soundtrack)"
date: 2018-09-27T10:30:42+00:00 
draft: false
year: "2017"
artist: "Konami Kukeiha Club"
album_name: "Contra (Original Video Game Soundtrack)"
format: "LP, Red/Blue Split"
video: "O04bPRzqEEk"
cover: "/uploads/2018/09/IMG_0115.jpg"
images: ["/uploads/2018/09/IMG_0117.jpg", "/uploads/2018/09/IMG_0114.jpg", "/uploads/2018/09/IMG_0113.jpg", "/uploads/2018/09/IMG_0116.jpg"]
---
