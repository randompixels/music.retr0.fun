---
title: "Cypress Hill — IV"
date: 2018-02-13T07:09:17+00:00 
draft: false
year: "1998 (Reissued 2017)"
artist: "Cypress Hill"
album_name: "IV"
format: "2xLP"
video: "QrWnH7cV_-c"
cover: "/uploads/2018/02/IMG_3143-1024x1024.jpg"
images: ["/uploads/2018/02/IMG_3141.jpg", "/uploads/2018/02/IMG_3146.jpg", "/uploads/2018/02/IMG_3144.jpg"]
---
