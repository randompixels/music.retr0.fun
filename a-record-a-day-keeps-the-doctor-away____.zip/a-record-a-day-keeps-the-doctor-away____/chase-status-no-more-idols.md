---
title: "Chase & Status — No More Idols"
date: 2019-04-14T11:23:05+00:00 
draft: false
year: "2011 (Reissued 2019)"
artist: "Chase & Status"
album_name: "No More Idols"
format: "2xLP, Yellow, Limited Edition, Record Store Day 2019"
video: "smY1SCNTrys"
cover: "/uploads/2019/04/IMG_5973.jpg"
images: ["/uploads/2019/04/IMG_5970.jpg", "/uploads/2019/04/IMG_5975.jpg", "/uploads/2019/04/IMG_5976.jpg", "/uploads/2019/04/IMG_5972.jpg", "/uploads/2019/04/IMG_5979.jpg", "/uploads/2019/04/IMG_5978.jpg"]
---
