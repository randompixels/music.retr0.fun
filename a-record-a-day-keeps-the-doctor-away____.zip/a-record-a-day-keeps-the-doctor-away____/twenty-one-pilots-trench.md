---
title: "Twenty One Pilots — Trench"
date: 2018-12-07T12:34:08+00:00 
draft: false
year: "2018"
artist: "Twenty One Pilots"
album_name: "Trench"
format: "2xLP, Gatefold, Translucent Yellow, + 10\", Translucent Yellow"
video: "7XkZZT0H4VY"
cover: "/uploads/2018/12/IMG_1040_a-1024x1024.jpg"
images: ["/uploads/2018/12/IMG_1037.jpg", "/uploads/2018/12/IMG_1036.jpg", "/uploads/2018/12/IMG_1035.jpg", "/uploads/2018/12/IMG_1041.jpg", "/uploads/2018/12/IMG_1042.jpg", "/uploads/2018/12/IMG_1034.jpg", "/uploads/2018/12/IMG_1032.jpg", "/uploads/2018/12/IMG_1033.jpg", "/uploads/2018/12/IMG_1031.jpg"]
---
