---
title: "John Williams — Star Wars - Episode VII: The Force Awakens (Soundtrack)"
date: 2018-04-03T05:54:13+00:00 
draft: false
year: "2016"
artist: "John Williams"
album_name: "Star Wars - Episode VII: The Force Awakens (Soundtrack)"
format: "2xLP, Etched (TIE Fighter & Millennium Falcon etching)"
video: "65As1V0vQDM"
cover: "/uploads/2018/03/IMG_3543.jpg"
images: ["/uploads/2018/03/IMG_4375-1.jpg", "/uploads/2018/03/IMG_1093.jpg", "/uploads/2018/03/IMG_3950-2.jpg", "/uploads/2018/03/IMG_4374.gif", "/uploads/2018/03/IMG_4378.gif"]
---
