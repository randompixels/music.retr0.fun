---
title: "Timpuri Noi — Timpuri Noi"
date: 2018-02-11T12:10:08+00:00 
draft: false
year: "1992"
artist: "Timpuri Noi"
album_name: "Timpuri Noi"
format: "LP"
video: "TbbUEEIhhrI"
cover: "/uploads/2018/02/IMG_3121-1024x1024.jpg"
images: ["/uploads/2018/02/IMG_3120.jpg", "/uploads/2018/02/IMG_3122.jpg", "/uploads/2018/02/IMG_3123.jpg"]
---
