---
title: "Kosheen — Resist"
date: 2018-01-31T11:37:03+00:00 
draft: false
year: "2001"
artist: "Kosheen"
album_name: "Resist"
format: "2xLP"
video: "Qm8EqbxkWco"
cover: "/uploads/2018/01/IMG_2880-1024x1024.jpg"
images: ["/uploads/2018/01/IMG_2879.jpg", "/uploads/2018/01/IMG_2881.jpg", "/uploads/2018/01/IMG_2882.jpg"]
---
