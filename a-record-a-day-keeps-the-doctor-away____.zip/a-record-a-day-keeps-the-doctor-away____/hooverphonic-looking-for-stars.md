---
title: "Hooverphonic – Looking for Stars"
date: 2019-06-17T22:04:40+03:00
lastmod: 2019-06-17T22:04:40+03:00
draft: false
year: "2018"
artist: "Hooverphonic"
album_name: "Looking For Stars"
format: "LP"
video: "Gb7tI7zL9E"
cover: "/uploads/2019/IMG_7322.JPG"
images: ['/uploads/2019/IMG_7325-wide.JPG', '/uploads/2019/IMG_7324-wide.JPG', '/uploads/2019/IMG_7323.JPG', '/uploads/2019/IMG_7347.JPG', '/uploads/2019/IMG_7348.JPG', '/uploads/2019/IMG_7349.JPG', '/uploads/2019/IMG_7350.JPG']
---
