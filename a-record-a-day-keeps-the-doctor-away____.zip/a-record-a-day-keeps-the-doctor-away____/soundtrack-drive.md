---
title: "Cliff Martinez — Drive (Soundtrack)"
date: 2017-03-26T12:44:27+00:00 
draft: false
year: "2016"
artist: "Cliff Martinez"
album_name: "Drive (Soundtrack)"
format: "2xLP, Gatefold, Neon Pink"
video: "BHgYtKkSEDA"
cover: "/uploads/2017/03/FullSizeRender-5-1024x1024.jpg"
images: ["/uploads/2017/03/IMG_8379-e1490456609559.jpg", "/uploads/2017/03/FullSizeRender-6.jpg", "/uploads/2017/03/FullSizeRender_34-1.jpg"]
---
