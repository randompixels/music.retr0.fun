---
title: "Various Artists — Stranger Things (Music From The Netflix Original Series)"
date: 2018-03-26T09:57:55+00:00 
draft: false
year: "2017"
artist: "Various Artists"
album_name: "Stranger Things (Music From The Netflix Original Series)"
format: "2xLP"
video: "Xr4jvECThGA"
cover: "/uploads/2018/03/IMG_4183-1024x1024.jpg"
images: ["/uploads/2018/03/IMG_4184.jpg", "/uploads/2018/03/IMG_4191.jpg", "/uploads/2018/03/IMG_4188.jpg"]
---
