---
title: "Bitză — Sevraj"
date: 2017-03-29T10:20:00+00:00 
draft: false
year: "2004"
artist: "Bitză"
album_name: "Sevraj"
format: "LP"
video: "EjTbKj-2hT8"
cover: "/uploads/2017/03/IMG_8552-e1490782783198-1024x1024.jpg"
images: ["/uploads/2017/03/IMG_8553-e1490782865370.jpg", "/uploads/2017/03/IMG_8554-e1490782588731.jpg", "/uploads/2017/03/IMG_8556-e1490782968860.jpg"]
---
