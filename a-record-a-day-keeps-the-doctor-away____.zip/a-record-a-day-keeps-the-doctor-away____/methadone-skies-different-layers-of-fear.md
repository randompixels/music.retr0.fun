---
title: "Methadone Skies — Different Layers Of Fear"
date: 2019-06-10T15:31:41+00:00 
draft: false
year: "2019"
artist: "Methadone Skies"
album_name: "Different Layers Of Fear"
format: "2xLP, Lilac with Blue and White Splatter + Pink with Blue and White Splatter "
video: "355AzGgBkgI"
cover: "/uploads/2019/06/IMG_7420.jpg"
images: ["/uploads/2019/06/IMG_7421.jpg", "/uploads/2019/06/IMG_7447.jpg", "/uploads/2019/06/IMG_7448.jpg", "/uploads/2019/06/IMG_7422.jpg"]
---
