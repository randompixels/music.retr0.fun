---
title: "John Williams — Star Wars - Episode VI: Return Of The Jedi (Soundtrack)"
date: 2018-04-02T11:30:29+00:00 
draft: false
year: "1983 (Reissued 2016)"
artist: "John Williams"
album_name: "Star Wars - Episode VI: Return Of The Jedi (Soundtrack)"
format: "2xLP, Gold"
video: "9HXwju2UXio"
cover: "/uploads/2018/03/IMG_4367.jpg"
images: ["/uploads/2018/03/IMG_4371.jpg", "/uploads/2018/03/IMG_4368.jpg", "/uploads/2018/03/IMG_4369-1.jpg", "/uploads/2018/03/IMG_4363.jpg", "/uploads/2018/03/IMG_4364.jpg", "/uploads/2018/03/IMG_4366.jpg"]
---
