---
title: "The Verve — Urban Hymns"
date: 2017-05-16T14:41:35+00:00 
draft: false
year: "2016"
artist: "The Verve"
album_name: "Urban Hymns"
format: "2xLP"
video: "ToQ0n3itoII"
cover: "/uploads/2017/05/IMG_9771-1024x1024.jpg"
images: ["/uploads/2017/05/IMG_9773.jpg", "/uploads/2017/05/IMG_9770-1.jpg", "/uploads/2017/05/IMG_9772-4.jpg"]
---
