---
title: "Danny Elfman — Justice League (Soundtrack)"
date: 2018-03-27T09:54:10+00:00 
draft: false
year: "2018"
artist: "Danny Elfman"
album_name: "Justice League (Soundtrack)"
format: "2xLP, Blue & Black"
video: "ojyuFzWA0v4"
cover: "/uploads/2018/03/IMG_4245-1024x1024.jpg"
images: ["/uploads/2018/03/IMG_4246.jpg", "/uploads/2018/03/IMG_4243.jpg", "/uploads/2018/03/IMG_4247.jpg"]
---
