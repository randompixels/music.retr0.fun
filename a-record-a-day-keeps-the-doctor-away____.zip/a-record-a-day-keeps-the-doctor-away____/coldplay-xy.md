---
title: "Coldplay — X&Y"
date: 2017-04-27T17:26:37+00:00 
draft: false
year: "2005"
artist: "Coldplay"
album_name: "X&Y"
format: "2xLP, Gatefold"
video: "EH9meoWmAOM"
cover: "/uploads/2017/04/IMG_9367-1024x1024.jpg"
images: ["/uploads/2017/04/IMG_9372.jpg", "/uploads/2017/04/IMG_9369.jpg", "/uploads/2017/04/IMG_9370-1.jpg"]
---
