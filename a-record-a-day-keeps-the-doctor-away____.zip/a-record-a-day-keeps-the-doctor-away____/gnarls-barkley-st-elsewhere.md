---
title: "Gnarls Barkley — St. Elsewhere"
date: 2017-05-11T14:31:52+00:00 
draft: false
year: "2006"
artist: "Gnarls Barkley"
album_name: "St. Elsewhere"
format: "LP"
video: "bd2B6SjMh_w"
cover: "/uploads/2017/05/IMG_9721-1024x1024.jpg"
images: ["/uploads/2017/05/IMG_9722.jpg", "/uploads/2017/05/IMG_9724.jpg", "/uploads/2017/05/IMG_9723-3.jpg"]
---
