---
title: "Pedro Bromfman — Narcos (Soundtrack)"
date: 2017-05-15T12:36:37+00:00 
draft: false
year: "2016"
artist: "Pedro Bromfman"
album_name: "Narcos (Soundtrack)"
format: "2xLP, Limited, Black and White halves"
video: "sabrtrKjC3A"
cover: "/uploads/2017/05/IMG_9762-1024x1024.jpg"
images: ["/uploads/2017/05/IMG_9763.jpg", "/uploads/2017/05/IMG_9761.jpg", "/uploads/2017/05/IMG_9765-1.jpg"]
---
