---
title: "Celelalte Cuvinte — Celelalte Cuvinte"
date: 2018-02-07T12:25:05+00:00 
draft: false
year: "1987"
artist: "Celelalte Cuvinte"
album_name: "Celelalte Cuvinte"
format: "LP"
video: "vxDFtFGUYag"
cover: "/uploads/2018/02/IMG_3034-1024x1024.jpg"
images: ["/uploads/2018/02/IMG_3035.jpg", "/uploads/2018/02/IMG_3032.jpg", "/uploads/2018/02/IMG_3033.jpg"]
---
