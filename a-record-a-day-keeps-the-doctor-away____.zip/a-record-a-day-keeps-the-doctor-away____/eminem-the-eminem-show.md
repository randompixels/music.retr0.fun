---
title: "Eminem — The Eminem Show"
date: 2018-02-18T10:16:51+00:00 
draft: false
year: "2002 (Reissued 2013)"
artist: "Eminem"
album_name: "The Eminem Show"
format: "2xLP"
video: "D4hAVemuQXY"
cover: "/uploads/2018/02/IMG_3279-1024x1024.jpg"
images: ["/uploads/2018/02/IMG_3278.jpg", "/uploads/2018/02/IMG_3280.jpg", "/uploads/2018/02/IMG_3281.jpg"]
---
