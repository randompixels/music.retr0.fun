---
title: "Kyle Dixon & Michael Stein — Stranger Things - Season One - Volume Two (Soundtrack)"
date: 2017-04-20T09:27:23+00:00 
draft: false
year: "2016"
artist: "Kyle Dixon & Michael Stein"
album_name: "Stranger Things - Season One - Volume Two (Soundtrack)"
format: "2xLP, Gatefold, Frosted Clear With White Blue And Red Splatter"
video: "ylSO-V6K74I"
cover: "/uploads/2017/04/IMG_9221-2-1024x1024.jpg"
images: ["/uploads/2017/04/FullSizeRender-7.jpg", "/uploads/2017/04/FullSizeRender-8.jpg", "/uploads/2017/04/IMG_9209.jpg"]
---
