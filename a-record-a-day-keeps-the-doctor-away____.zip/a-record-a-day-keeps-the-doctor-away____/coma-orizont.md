---
title: "Coma — Orizont"
date: 2017-04-26T17:48:45+00:00 
draft: false
year: "2016"
artist: "Coma"
album_name: "Orizont"
format: "LP"
video: "cFmjO4mY1zs"
cover: "/uploads/2017/04/IMG_9322-1024x1024.jpg"
images: ["/uploads/2017/04/46391929_10215478244523892_9005394097166352384_o.jpg", "/uploads/2017/04/IMG_9324.jpg", "/uploads/2017/04/FullSizeRender-6-2.jpg"]
---
