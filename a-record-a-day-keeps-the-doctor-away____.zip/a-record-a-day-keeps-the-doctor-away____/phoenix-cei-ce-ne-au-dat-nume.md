---
title: "Phoenix — Cei Ce Ne-au Dat Nume"
date: 2017-04-22T13:04:52+00:00 
draft: false
year: "1975"
artist: "Phoenix"
album_name: "Cei Ce Ne-au Dat Nume"
format: "LP"
video: "GpBOoPrlDsM"
cover: "/uploads/2017/04/IMG_9266-1024x1024.jpg"
images: ["/uploads/2017/04/IMG_9269.jpg", "/uploads/2017/04/IMG_9267-2.jpg", "/uploads/2017/04/IMG_9268-5.jpg"]
---
