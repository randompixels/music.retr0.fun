---
title: "John Williams — Star Wars - Episode III: Revenge Of The Sith (Soundtrack)"
date: 2018-03-30T09:06:35+00:00 
draft: false
year: "2005 (Reissued 2016)"
artist: "John Williams"
album_name: "Star Wars - Episode III: Revenge Of The Sith (Soundtrack)"
format: "2xLP, Cyan/Green (General Grievous), Limited - 1000"
video: "tQb6C-RyjDI"
cover: "/uploads/2018/03/IMG_4326.jpg"
images: ["/uploads/2018/03/IMG_4325.jpg", "/uploads/2018/03/IMG_4328.jpg", "/uploads/2018/03/IMG_4329.jpg"]
---
