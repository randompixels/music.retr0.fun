---
title: "Rodion G.A. — Rozalia"
date: 2019-01-25T17:19:48+00:00 
draft: false
year: "2018"
artist: "Rodion G.A."
album_name: "Rozalia"
format: "LP, Signed"
video: "gMloZhaQidk"
cover: "/uploads/2019/01/IMG_2764.jpg"
images: ["/uploads/2019/01/IMG_2765.jpg", "/uploads/2019/01/IMG_2770.jpg", "/uploads/2019/01/IMG_2767.jpg", "/uploads/2019/01/IMG_2768.jpg", "/uploads/2019/01/IMG_2769.jpg", "/uploads/2019/01/IMG_2766.jpg"]
---
