---
title: "Michael Jackson — Bad"
date: 2018-11-03T16:43:24+00:00 
draft: false
year: "1987 (2016 Reissued)"
artist: "Michael Jackson"
album_name: "Bad"
format: "LP"
video: "yUi_S6YWjZw"
cover: "/uploads/2018/11/IMG_1129.jpg"
images: ["/uploads/2018/11/IMG_1130.jpg", "/uploads/2018/11/IMG_1127.jpg", "/uploads/2018/11/IMG_1131.jpg"]
---
