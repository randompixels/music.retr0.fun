---
title: "Groove Armada — Goodbye Country (Hello Nightclub)"
date: 2017-04-29T10:37:30+00:00 
draft: false
year: "2001"
artist: "Groove Armada"
album_name: "Goodbye Country (Hello Nightclub)"
format: "3xLP, Gatefold"
video: "k0LOqB69_1M"
cover: "/uploads/2017/04/IMG_9402-1024x1024.jpg"
images: ["/uploads/2017/04/IMG_9408.jpg", "/uploads/2017/04/IMG_9409.jpg", "/uploads/2017/04/IMG_9401-3.jpg"]
---
