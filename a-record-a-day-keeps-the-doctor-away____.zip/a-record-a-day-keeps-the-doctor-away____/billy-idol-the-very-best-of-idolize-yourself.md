---
title: "Billy Idol — The Very Best Of - Idolize Yourself"
date: 2018-05-16T08:10:49+00:00 
draft: false
year: "2017"
artist: "Billy Idol"
album_name: "The Very Best Of - Idolize Yourself"
format: "2xLP"
video: "fLjE-2_Luaw"
cover: "/uploads/2018/05/IMG_5545-1024x1024.jpg"
images: ["/uploads/2018/05/IMG_5547.jpg", "/uploads/2018/05/IMG_5550.jpg", "/uploads/2018/05/IMG_5548.jpg"]
---
