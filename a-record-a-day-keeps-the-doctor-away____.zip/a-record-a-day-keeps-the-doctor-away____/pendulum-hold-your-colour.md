---
title: "Pendulum — Hold Your Colour"
date: 2018-01-29T17:49:32+00:00 
draft: false
year: "2005"
artist: "Pendulum"
album_name: "Hold Your Colour"
format: "3x12\""
video: "k-Xv0sKBMA8"
cover: "/uploads/2018/01/IMG_2863-1024x1024.jpg"
images: ["/uploads/2018/01/IMG_2862.jpg", "/uploads/2018/01/IMG_2864.jpg"]
---
