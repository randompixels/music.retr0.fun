---
title: "John Williams — Star Wars - Episode I: The Phantom Menace (Soundtrack)"
date: 2018-03-28T08:13:07+00:00 
draft: false
year: "1999 (Reissued 2015)"
artist: "John Williams"
album_name: "Star Wars - Episode I: The Phantom Menace (Soundtrack)"
format: "2xLP, Black w/ Red & Gold Effect, Limited - 2000"
video: "xlYCxbBZUCY"
cover: "/uploads/2018/03/IMG_4277.jpg"
images: ["/uploads/2018/03/IMG_4273.jpg", "/uploads/2018/03/IMG_4278.jpg", "/uploads/2018/03/IMG_4279.jpg"]
---
