---
title: "Gorillaz — Humanz"
date: 2017-06-08T14:59:03+00:00 
draft: false
year: "2017"
artist: "Gorillaz"
album_name: "Humanz"
format: "2xLP, Gateford"
video: "CU84AvL7zo0"
cover: "/uploads/2017/06/IMG_0236-3-1024x1024.jpg"
images: ["/uploads/2017/06/IMG_0238.jpg", "/uploads/2017/06/IMG_0232-3.jpg", "/uploads/2017/06/IMG_0239-2.jpg"]
---
