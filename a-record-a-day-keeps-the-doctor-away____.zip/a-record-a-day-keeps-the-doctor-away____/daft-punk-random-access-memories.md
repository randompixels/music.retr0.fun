---
title: "Daft Punk — Random Access Memories"
date: 2018-01-30T09:45:45+00:00 
draft: false
year: "2013"
artist: "Daft Punk"
album_name: "Random Access Memories"
format: "2xLP"
video: "JI5noh4OyXc"
cover: "/uploads/2018/01/IMG_2870-1024x1024.jpg"
images: ["/uploads/2018/01/IMG_2869.jpg", "/uploads/2018/01/IMG_2872.jpg", "/uploads/2018/01/IMG_2871.jpg"]
---
