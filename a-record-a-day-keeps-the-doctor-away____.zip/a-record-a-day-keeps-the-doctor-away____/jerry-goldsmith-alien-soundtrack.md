---
title: "Jerry Goldsmith — Alien (Soundtrack)"
date: 2018-01-18T09:02:06+00:00 
draft: false
year: "2017"
artist: "Jerry Goldsmith"
album_name: "Alien (Soundtrack)"
format: "2xLP, Acid-Blood Green"
video: "F8hPSRawVjo"
cover: "/uploads/2018/01/IMG_2487-1024x1024.jpg"
images: ["/uploads/2018/01/IMG_2486.jpg", "/uploads/2018/01/IMG_2488.jpg", "/uploads/2018/01/IMG_2485.jpg"]
---
