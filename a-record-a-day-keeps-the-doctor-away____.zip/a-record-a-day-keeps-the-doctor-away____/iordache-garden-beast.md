---
title: "Iordache — Garden Beast"
date: 2019-01-27T11:22:09+00:00 
draft: false
year: ""
artist: "Iordache"
album_name: "Garden Beast"
format: "LP, Limited Edition: 100"
video: "R4I8NTUijfY"
cover: "/uploads/2019/01/IMG_2834.jpg"
images: ["/uploads/2019/01/IMG_2832.jpg", "/uploads/2019/01/IMG_2843.jpg", "/uploads/2019/01/IMG_2836.jpg"]
---
