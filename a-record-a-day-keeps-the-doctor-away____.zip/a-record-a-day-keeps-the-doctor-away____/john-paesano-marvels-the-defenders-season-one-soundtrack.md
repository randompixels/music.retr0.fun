---
title: "John Paesano — Marvel's The Defenders - Season One (Soundtrack)"
date: 2018-07-13T10:05:41+00:00 
draft: false
year: "2018"
artist: "John Paesano"
album_name: "Marvel's The Defenders - Season One (Soundtrack)"
format: "2xLP, Red/Yellow split + Purple/Green split "
video: ""
cover: "/uploads/2018/07/IMG_7455-1024x1024.jpg"
images: ["/uploads/2018/07/IMG_7458.jpg", "/uploads/2018/07/IMG_7457.jpg", "/uploads/2018/07/IMG_7460.jpg", "/uploads/2018/07/IMG_7461.jpg", "/uploads/2018/07/IMG_7456.jpg"]
---
