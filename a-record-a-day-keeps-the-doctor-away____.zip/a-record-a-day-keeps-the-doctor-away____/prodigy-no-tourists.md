---
title: "Prodigy — No Tourists"
date: 2018-12-08T19:01:55+00:00 
draft: false
year: "2018"
artist: "Prodigy"
album_name: "No Tourists"
format: "2xLP, Gatefold, Transparent, CD, Cassette"
video: "BVMDy3fu6rs"
cover: "/uploads/2018/12/prodigy-no_tourists-1024x1024.jpg"
images: ["/uploads/2018/12/IMG_1053.jpg", "/uploads/2018/12/IMG_1044.jpg", "/uploads/2018/12/IMG_1045.jpg", "/uploads/2018/12/IMG_1046.jpg", "/uploads/2018/12/IMG_1047.jpg", "/uploads/2018/12/IMG_1048.jpg", "/uploads/2018/12/IMG_1055.jpg", "/uploads/2018/12/IMG_1061.jpg", "/uploads/2018/12/IMG_1062.jpg"]
---
