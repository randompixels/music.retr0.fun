---
title: "Hooverphonic — The Night Before"
date: 2019-04-04T11:16:09+00:00 
draft: false
year: "2010 (Repressed in 2019)"
artist: "Hooverphonic"
album_name: "The Night Before"
format: "LP & LP Repressed on Red Translucid"
video: "2P78nxoE_JY"
cover: "/uploads/2019/04/IMG_5617-1024x1024.jpg"
images: ["/uploads/2019/04/IMG_5625.jpg", "/uploads/2019/04/IMG_5622.jpg", "/uploads/2019/04/IMG_5615.jpg", "/uploads/2019/04/IMG_5612.jpg", "/uploads/2019/04/IMG_5613.jpg", "/uploads/2019/04/IMG_5614.jpg", "/uploads/2019/04/IMG_5619.jpg", "/uploads/2019/04/IMG_5618.jpg", "/uploads/2019/04/IMG_5616.jpg"]
---
