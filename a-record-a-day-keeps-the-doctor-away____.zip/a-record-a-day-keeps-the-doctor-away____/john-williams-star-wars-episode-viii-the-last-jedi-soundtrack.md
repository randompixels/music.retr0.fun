---
title: "John Williams — Star Wars - Episode VIII: The Last Jedi (Soundtrack)"
date: 2018-04-04T09:34:22+00:00 
draft: false
year: "2018"
artist: "John Williams"
album_name: "Star Wars - Episode VIII: The Last Jedi (Soundtrack)"
format: "2xLP"
video: "8FviFi42Y4c"
cover: "/uploads/2018/03/IMG_4387-1.jpg"
images: ["/uploads/2018/03/IMG_4390.jpg", "/uploads/2018/03/IMG_4388.jpg", "/uploads/2018/03/IMG_2697.jpg"]
---
