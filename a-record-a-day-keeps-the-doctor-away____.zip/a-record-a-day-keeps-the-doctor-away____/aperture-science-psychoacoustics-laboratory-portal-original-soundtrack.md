---
title: "Aperture Science Psychoacoustics Laboratory — Portal Original Soundtrack"
date: 2018-03-21T08:55:59+00:00 
draft: false
year: "2017"
artist: "Aperture Science Psychoacoustics Laboratory"
album_name: "Portal Original Soundtrack"
format: "Limited Edition, White & Gray Split, 'Magic Wallet' Sleeve"
video: "Y6ljFaKRTrI"
cover: "/uploads/2018/03/IMG_3964-1024x1024.jpg"
images: ["/uploads/2018/03/IMG_3967.jpg", "/uploads/2018/03/IMG_3965.jpg", "/uploads/2018/03/IMG_3966.jpg"]
---
