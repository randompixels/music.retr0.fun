---
title: "Various — Cerbul de Aur 2018 - Nostalgia"
date: 2018-12-30T23:59:31+00:00 
draft: false
year: "2018"
artist: "Various"
album_name: "Cerbul de Aur 2018 - Nostalgia"
format: "LP"
video: "l3wUZL8HkKY"
cover: "/uploads/2018/12/IMG_2010-1024x1024.jpg"
images: ["/uploads/2018/12/IMG_2002.jpg", "/uploads/2018/12/IMG_2007.jpg", "/uploads/2018/12/IMG_2015.jpg", "/uploads/2018/12/IMG_2003.jpg"]
---
