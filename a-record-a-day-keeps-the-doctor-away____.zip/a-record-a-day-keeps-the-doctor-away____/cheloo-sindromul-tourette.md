---
title: "Cheloo — Sindromul Tourette"
date: 2018-02-17T10:13:46+00:00 
draft: false
year: "2003"
artist: "Cheloo"
album_name: "Sindromul Tourette"
format: "LP, Limited Edition, Numbered. 244/500"
video: "7yKDhm4_-90"
cover: "/uploads/2018/02/IMG_3234-1024x1024.jpg"
images: ["/uploads/2018/02/IMG_3232.jpg", "/uploads/2018/02/IMG_3235.jpg", "/uploads/2018/02/IMG_3236.jpg"]
---
