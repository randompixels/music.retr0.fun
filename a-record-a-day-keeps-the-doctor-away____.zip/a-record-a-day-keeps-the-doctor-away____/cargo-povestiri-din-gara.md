---
title: "Cargo — Povestiri Din Gară"
date: 2018-02-06T13:49:40+00:00 
draft: false
year: "1993, Reissue, Yellow Cover"
artist: "Cargo"
album_name: "Povestiri Din Gară"
format: "LP"
video: "K3QHo7o9eGE"
cover: "/uploads/2018/02/IMG_3024-1024x1024.jpg"
images: ["/uploads/2018/02/IMG_3020.jpg", "/uploads/2018/02/IMG_3022.jpg", "/uploads/2018/02/IMG_3025.jpg"]
---
