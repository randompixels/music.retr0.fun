---
title: "Limp Bizkit — Significant Other"
date: 2017-06-01T12:42:38+00:00 
draft: false
year: "1999"
artist: "Limp Bizkit"
album_name: "Significant Other"
format: "2xLP, Gatefold, Red"
video: "9QWOc0HnItM"
cover: "/uploads/2017/06/IMG_0113-1024x1024.jpg"
images: ["/uploads/2017/06/IMG_0112.jpg", "/uploads/2017/06/IMG_0111.jpg", "/uploads/2017/06/IMG_0114-2.jpg"]
---
