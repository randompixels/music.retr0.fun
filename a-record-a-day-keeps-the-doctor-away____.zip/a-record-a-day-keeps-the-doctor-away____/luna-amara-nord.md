---
title: "Luna Amară — Nord"
date: 2019-02-03T11:08:30+00:00 
draft: false
year: "2019"
artist: "Luna Amară"
album_name: "Nord"
format: "2xLP, 45RPM, Frosted White Translucent"
video: "zDbtxHwe7n8"
cover: "/uploads/2019/02/IMG_3174.jpg"
images: ["/uploads/2019/02/IMG_3180-double.jpg", "/uploads/2019/02/IMG_3177.jpg", "/uploads/2019/02/IMG_3190-double.jpg", "/uploads/2019/02/IMG_3178.jpg", "/uploads/2019/02/IMG_3175.jpg", "/uploads/2019/02/IMG_3198.jpg"]
---
