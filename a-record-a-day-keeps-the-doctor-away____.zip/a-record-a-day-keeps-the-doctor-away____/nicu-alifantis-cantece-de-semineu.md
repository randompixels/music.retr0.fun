---
title: "Nicu Alifantis — Cântece De Șemineu"
date: 2019-02-02T11:31:45+00:00 
draft: false
year: "2010"
artist: "Nicu Alifantis"
album_name: "Cântece De Șemineu"
format: "LP"
video: "e74zq-RARGc"
cover: "/uploads/2019/02/IMG_3085.jpg"
images: ["/uploads/2019/02/IMG_3086.jpg", "/uploads/2019/02/IMG_3082.jpg", "/uploads/2019/02/IMG_3087.jpg"]
---
