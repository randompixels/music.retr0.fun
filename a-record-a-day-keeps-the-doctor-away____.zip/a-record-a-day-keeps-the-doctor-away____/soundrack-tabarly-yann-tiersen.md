---
title: "Yann Tiersen — Tabarly (Soundtrack)"
date: 2017-05-31T11:35:46+00:00 
draft: false
year: "2008"
artist: "Yann Tiersen"
album_name: "Tabarly (Soundtrack)"
format: "LP"
video: "m4kRciR7Eo4"
cover: "/uploads/2017/05/IMG_0098-1024x1024.jpg"
images: ["/uploads/2017/05/IMG_0101.jpg", "/uploads/2017/05/IMG_0099.jpg", "/uploads/2017/05/IMG_0100-1.jpg"]
---
