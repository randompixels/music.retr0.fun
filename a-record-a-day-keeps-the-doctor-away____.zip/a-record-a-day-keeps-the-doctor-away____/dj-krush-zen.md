---
title: "DJ Krush — 漸 (Zen)"
date: 2017-05-20T19:34:56+00:00 
draft: false
year: "1998, Reissued in 2010"
artist: "DJ Krush"
album_name: "漸 (Zen)"
format: "2xLP"
video: "ycvOoAATBL0"
cover: "/uploads/2017/05/IMG_9827.jpg"
images: ["/uploads/2017/05/IMG_9828.jpg", "/uploads/2017/05/IMG_9826.jpg", "/uploads/2017/05/IMG_9824.jpg"]
---
