---
title: "Kyle Dixon & Michael Stein — Stranger Things 2 (Soundtrack)"
date: 2018-03-25T16:12:34+00:00 
draft: false
year: "2017"
artist: "Kyle Dixon & Michael Stein"
album_name: "Stranger Things 2 (Soundtrack)"
format: "2xLP, Crystal Purple w/ White Splatter"
video: "vXwBqMUhAu4"
cover: "/uploads/2018/03/IMG_4174-1024x1024.jpg"
images: ["/uploads/2018/03/IMG_4170.jpg", "/uploads/2018/03/IMG_4175.jpg", "/uploads/2018/03/IMG_4177.jpg"]
---
