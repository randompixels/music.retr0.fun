---
title: "Dr. Dre — 2001"
date: 2018-02-14T10:02:24+00:00 
draft: false
year: "1999 (Reissued 2011)"
artist: "Dr. Dre"
album_name: "2001"
format: "2xLP"
video: "_CL6n0FJZpk"
cover: "/uploads/2018/02/IMG_3176-1024x1024.jpg"
images: ["/uploads/2018/02/IMG_3173.jpg", "/uploads/2018/02/IMG_3177.jpg"]
---
