---
title: "Jain — Zanaka"
date: 2019-06-03T09:45:57+00:00 
draft: false
year: "2016"
artist: "Jain"
album_name: "Zanaka"
format: "2xLP, 45 RPM, Etched"
video: "KDXOzr0GoA4"
cover: "/uploads/2019/05/IMG_7071.jpg"
images: ["/uploads/2019/05/IMG_7072.jpg", "/uploads/2019/05/IMG_7033.jpg", "/uploads/2019/05/IMG_7034.jpg"]
---
