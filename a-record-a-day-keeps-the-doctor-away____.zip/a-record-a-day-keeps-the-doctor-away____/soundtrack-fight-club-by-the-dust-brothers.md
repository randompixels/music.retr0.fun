---
title: "The Dust Brothers — Fight Club (Soundtrack)"
date: 2017-06-28T16:46:29+00:00 
draft: false
year: "2017"
artist: "The Dust Brothers"
album_name: "Fight Club (Soundtrack)"
format: "2xLP, Pink"
video: "AN6hAGVyRLE"
cover: "/uploads/2017/06/IMG_0868-1024x1024.jpg"
images: ["/uploads/2017/06/IMG_0863-2.jpg", "/uploads/2017/06/IMG_0867.jpg", "/uploads/2017/06/IMG_0865.jpg"]
---
