---
title: "Various — Babylon Berlin (Soundtrack)"
date: 2018-08-06T07:10:56+00:00 
draft: false
year: "2018"
artist: "Various"
album_name: "Babylon Berlin (Soundtrack)"
format: "3xLP + 2xCD, Triple Gatefold"
video: "uekZpkYf7-E"
cover: "/uploads/2018/08/IMG_7905.jpg"
images: ["/uploads/2018/08/IMG_7907.jpg", "/uploads/2018/08/IMG_7908.jpg", "/uploads/2018/08/IMG_7909.jpg", "/uploads/2018/08/IMG_7914.jpg", "/uploads/2018/08/IMG_7906.jpg", "/uploads/2018/08/IMG_7910.jpg", "/uploads/2018/08/IMG_7913.jpg", "/uploads/2018/08/IMG_7916.jpg"]
---
