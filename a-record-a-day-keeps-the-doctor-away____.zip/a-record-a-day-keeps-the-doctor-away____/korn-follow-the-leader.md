---
title: "Korn — Follow the Leader"
date: 2017-07-08T09:27:42+00:00 
draft: false
year: "1997, Reissued 2014"
artist: "Korn"
album_name: "Follow the Leader"
format: "2xLP"
video: "jRGrNDV2mKc"
cover: "/uploads/2017/07/IMG_1066-1024x1024.jpg"
images: ["/uploads/2017/07/IMG_1067.jpg", "/uploads/2017/07/IMG_1065-2.jpg", "/uploads/2017/07/IMG_1068.jpg"]
---
