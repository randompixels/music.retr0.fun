---
title: "Elliott Smith — Either/Or (Expanded Edition)"
date: 2017-05-07T12:09:11+00:00 
draft: false
year: "2017"
artist: "Elliott Smith"
album_name: "Either/Or (Expanded Edition)"
format: "2xLP, Gatefold, Yellow, Remastered"
video: "NcalJSO6jDY"
cover: "/uploads/2017/05/IMG_9605-1-1024x1024.jpg"
images: ["/uploads/2017/05/IMG_9606-2.jpg", "/uploads/2017/05/FullSizeRender-8.jpg", "/uploads/2017/05/IMG_9607.jpg"]
---
