---
title: "The Last Shadow Puppets — The Age Of The Understatement"
date: 2018-11-05T11:22:43+00:00 
draft: false
year: "2015"
artist: "The Last Shadow Puppets"
album_name: "The Age Of The Understatement"
format: "LP"
video: "XGV8xCkpXjE"
cover: "/uploads/2018/11/IMG_1171.jpg"
images: ["/uploads/2018/11/IMG_1163.jpg", "/uploads/2018/11/IMG_1170.jpg", "/uploads/2018/11/IMG_1172.jpg", "/uploads/2018/11/IMG_1167.jpg", "/uploads/2018/11/IMG_1168-1.jpg"]
---
