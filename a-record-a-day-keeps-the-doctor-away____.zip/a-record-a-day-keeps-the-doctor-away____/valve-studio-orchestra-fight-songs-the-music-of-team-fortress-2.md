---
title: "Valve Studio Orchestra — Fight Songs: The Music Of Team Fortress 2 (Game Soundtrack)"
date: 2018-09-30T16:59:37+00:00 
draft: false
year: "2017"
artist: "Valve Studio Orchestra"
album_name: "Fight Songs: The Music Of Team Fortress 2 (Game Soundtrack)"
format: "2xLP, Red Translucent + Blue Translucent "
video: "i-7QDCfkaxY"
cover: "/uploads/2018/09/IMG_0202.jpg"
images: ["/uploads/2018/09/IMG_0203.jpg", "/uploads/2018/09/IMG_0215.jpg", "/uploads/2018/09/IMG_0217.jpg", "/uploads/2018/09/IMG_0204.jpg", "/uploads/2018/09/IMG_0214.jpg"]
---
