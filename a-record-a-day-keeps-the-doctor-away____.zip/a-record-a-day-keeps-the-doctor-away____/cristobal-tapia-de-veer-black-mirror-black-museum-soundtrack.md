---
title: "Cristobal Tapia De Veer — Black Mirror: Black Museum (Soundtrack)"
date: 2019-05-05T12:19:14+00:00 
draft: false
year: "2018"
artist: "Cristobal Tapia De Veer"
album_name: "Black Mirror: Black Museum (Soundtrack)"
format: "LP, Monkey Swirl (Brown & White)<br> LP, Single Sided, Black with Screen Printed D-side.<br>Limited Edition. 250 copies"
video: "QSJ6QKhi_Ao"
cover: "/uploads/2019/05/IMG_6575.jpg"
images: ["/uploads/2019/05/IMG_6576.jpg", "/uploads/2019/05/IMG_6577.jpg", "/uploads/2019/05/IMG_6578.jpg", "/uploads/2019/05/IMG_6570.jpg", "/uploads/2019/05/IMG_6571.jpg", "/uploads/2019/05/IMG_6573.jpg"]
---
