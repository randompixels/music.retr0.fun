---
title: "Implant Pentru Refuz — Cartography"
date: 2019-01-21T13:31:16+00:00 
draft: false
year: "2015"
artist: "Implant Pentru Refuz"
album_name: "Cartography"
format: "LP"
video: "Q1Ac743Hp3c"
cover: "/uploads/2019/01/IMG_2577-1024x1024.jpg"
images: ["/uploads/2019/01/IMG_2576.jpg", "/uploads/2019/01/IMG_2580.jpg", "/uploads/2019/01/IMG_2581.jpg"]
---
