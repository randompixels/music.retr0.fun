---
title: "Zdob Și Zdub — Basta Mafia!"
date: 2019-02-01T11:02:18+00:00 
draft: false
year: "2012"
artist: "Zdob Și Zdub"
album_name: "Basta Mafia!"
format: "LP"
video: "NO17cbQ377o"
cover: "/uploads/2019/02/IMG_3090.jpg"
images: ["/uploads/2019/02/IMG_3083.jpg", "/uploads/2019/02/IMG_3089.jpg", "/uploads/2019/02/IMG_3091.jpg"]
---
