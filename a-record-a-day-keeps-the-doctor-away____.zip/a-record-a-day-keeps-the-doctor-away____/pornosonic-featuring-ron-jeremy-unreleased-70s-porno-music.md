---
title: "Pornosonic & Ron Jeremy — Unreleased 70s Porno Music"
date: 2019-05-24T21:53:18+00:00 
draft: false
year: "2018"
artist: "Pornosonic & Ron Jeremy"
album_name: "Unreleased 70s Porno Music"
format: "LP, Limited Edition, 500 Copies, X-Rated Edition, in a discreet black wrap"
video: "18ljLPZEfjs"
cover: "/uploads/2019/05/IMG_6745.jpg"
images: ["/uploads/2019/05/IMG_6746.jpg", "/uploads/2019/05/IMG_6747.jpg", "/uploads/2019/05/IMG_6748.jpg", "/uploads/2019/05/IMG_6744.jpg", "/uploads/2019/05/IMG_6743.jpg"]
---
