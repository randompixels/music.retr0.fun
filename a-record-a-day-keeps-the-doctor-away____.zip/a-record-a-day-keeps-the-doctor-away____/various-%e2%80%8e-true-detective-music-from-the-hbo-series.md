---
title: "Various — True Detective (Music From the HBO Series)"
date: 2018-08-25T15:08:49+00:00 
draft: false
year: "2015"
artist: "Various"
album_name: "True Detective (Music From the HBO Series)"
format: "2xLP, Limited Edition to 2500, RSD2015"
video: "rSSVDGY0dP4"
cover: "/uploads/2018/08/IMG_8998.jpg"
images: ["/uploads/2018/08/IMG_8999.jpg", "/uploads/2018/08/IMG_9002.jpg", "/uploads/2018/08/IMG_9003.jpg", "/uploads/2018/08/IMG_9005.jpg", "/uploads/2018/08/IMG_9006.jpg", "/uploads/2018/08/IMG_9007.jpg", "/uploads/2018/08/IMG_9001.jpg", "/uploads/2018/08/IMG_8997.jpg"]
---
