---
title: "Grasu XXL — Drumul Spre Succes"
date: 2018-02-16T08:27:30+00:00 
draft: false
year: "LP, Picture"
artist: "Grasu XXL"
album_name: "Drumul Spre Succes"
format: "2016"
video: "Qh7Xcxstd4w"
cover: "/uploads/2018/02/IMG_3216-1024x1024.jpg"
images: ["/uploads/2018/02/IMG_3212.jpg", "/uploads/2018/02/IMG_3213.jpg"]
---
