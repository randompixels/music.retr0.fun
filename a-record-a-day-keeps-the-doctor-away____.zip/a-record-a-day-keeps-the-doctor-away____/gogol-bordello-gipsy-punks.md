---
title: "Gogol Bordello — Gipsy Punks"
date: 2017-05-18T16:18:11+00:00 
draft: false
year: "2016"
artist: "Gogol Bordello"
album_name: "Gipsy Punks"
format: "2xLP, Gatefold, Red"
video: "_6IJfo4q1zk"
cover: "/uploads/2017/05/IMG_9805-1-1024x1024.jpg"
images: ["/uploads/2017/05/IMG_9806.jpg", "/uploads/2017/05/FullSizeRender-6.jpg", "/uploads/2017/05/FullSizeRender-7.jpg"]
---
