---
title: "Kraftwerk — Tour De France"
date: 2018-02-01T12:00:08+00:00 
draft: false
year: "2009 (Reissued 2013)"
artist: "Kraftwerk"
album_name: "Tour De France"
format: "2xLP"
video: ""
cover: "/uploads/2018/02/IMG_2918-1024x1024.jpg"
images: ["/uploads/2018/02/IMG_2917.jpg", "/uploads/2018/02/IMG_2922.jpg", "/uploads/2018/02/IMG_2923.jpg"]
---
