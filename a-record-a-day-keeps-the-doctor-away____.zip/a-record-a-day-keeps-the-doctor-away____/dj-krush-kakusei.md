---
title: "DJ Krush — 覚醒 (Kakusei)"
date: 2017-05-20T14:01:18+00:00 
draft: false
year: "1999, Reissued in 2014"
artist: "DJ Krush"
album_name: "覚醒 (Kakusei)"
format: "2xLP"
video: "NCsPhnr6dVY"
cover: "/uploads/2017/05/IMG_9820-1024x1024.jpg"
images: ["/uploads/2017/05/IMG_9821-1.jpg", "/uploads/2017/05/IMG_9822.jpg"]
---
