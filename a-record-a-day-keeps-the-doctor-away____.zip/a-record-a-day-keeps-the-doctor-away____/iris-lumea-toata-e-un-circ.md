---
title: "Iris — Lumea Toată E Un Circ"
date: 2019-01-28T11:49:13+00:00 
draft: false
year: "2018"
artist: "Iris"
album_name: "Lumea Toată E Un Circ"
format: "2xLP"
video: "xVsARn0QwkE"
cover: "/uploads/2019/01/IMG_2847.jpg"
images: ["/uploads/2019/01/IMG_2846.jpg", "/uploads/2019/01/IMG_2844.jpg", "/uploads/2019/01/IMG_2849.jpg", "/uploads/2019/01/IMG_2851.jpg"]
---
