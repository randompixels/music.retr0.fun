---
title: "Long Tall Jefferson – I Want My Honey Back"
date: 2019-06-13T21:24:39+03:00
lastmod: 2019-06-13T21:24:39+03:00
draft: false
year: "2016"
artist: "Long Tall Jefferson"
album_name: "I Want My Honey Back"
format: "LP"
video: "ABo0C656rBo"
cover: "/uploads/2019/06/IMG_7407.JPG"
images: ['/uploads/2019/06/IMG_7408.JPG', '/uploads/2019/06/IMG_7449.JPG', '/uploads/2019/06/IMG_7451.JPG', '/uploads/2019/06/IMG_7517.JPG']
---
