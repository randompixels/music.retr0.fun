---
title: "Lauryn Hill — The Miseducation Of Lauryn Hill"
date: 2018-06-08T15:39:36+00:00 
draft: false
year: "1998 (Reissued 2018)"
artist: "Lauryn Hill"
album_name: "The Miseducation Of Lauryn Hill"
format: "2xLP, Limited Edition, Brown Marbled"
video: "T6QKqFPRZSA"
cover: "/uploads/2018/06/IMG_6763.jpg"
images: ["/uploads/2018/06/IMG_6764.jpg", "/uploads/2018/06/IMG_6768.jpg", "/uploads/2018/06/IMG_6762.jpg"]
---
