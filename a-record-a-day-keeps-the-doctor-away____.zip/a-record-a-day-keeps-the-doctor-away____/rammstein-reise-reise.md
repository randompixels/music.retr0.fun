---
title: "Rammstein — Reise, Reise"
date: 2018-05-03T16:34:04+00:00 
draft: false
year: "2004 (Reissued 2017)"
artist: "Rammstein"
album_name: "Reise, Reise"
format: "2xLP"
video: "LIPc1cfS-oQ"
cover: "/uploads/2018/05/IMG_5258.jpg"
images: ["/uploads/2018/05/IMG_5259.jpg", "/uploads/2018/05/IMG_5256.jpg", "/uploads/2018/05/IMG_5257.jpg"]
---
