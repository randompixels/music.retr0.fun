---
title: "Alex Somers — Captain Fantastic (Soundtrack)"
date: 2019-05-31T07:08:53+00:00 
draft: false
year: "2016"
artist: "Alex Somers"
album_name: "Captain Fantastic (Soundtrack)"
format: "2xLP, Limited Edition, Numbered, Special Edition, Limited to 1,150 copies<br>Comes with an exclusive lithograph signed and numbered by Alex Somers (150/350)"
video: "HuV6YmQLDq4"
cover: "/uploads/2019/05/IMG_7066.jpg"
images: ["/uploads/2019/05/IMG_7070.jpg", "/uploads/2019/05/IMG_7068.jpg", "/uploads/2019/05/IMG_7067.jpg", "/uploads/2019/05/IMG_7062.jpg", "/uploads/2019/05/IMG_7061.jpg"]
---
