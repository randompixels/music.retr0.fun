---
title: "Daniel Pemberton — Black Mirror: USS Callister (Soundtrack)"
date: 2019-05-21T10:20:35+00:00 
draft: false
year: "2019"
artist: "Daniel Pemberton"
album_name: "Black Mirror: USS Callister (Soundtrack)"
format: "2xLP, Red, Limited Edition, Record Store Day 2019<br>1000 Copies"
video: "pSUHg2pgcV4"
cover: "/uploads/2019/05/IMG_7013-1024x1024.jpg"
images: ["/uploads/2019/05/IMG_7014.jpg", "/uploads/2019/05/IMG_7015.jpg", "/uploads/2019/05/IMG_7012.jpg", "/uploads/2019/05/IMG_7017.jpg", "/uploads/2019/05/IMG_7016.jpg", "/uploads/2019/05/IMG_7018.jpg", "/uploads/2019/05/IMG_7019.jpg"]
---
