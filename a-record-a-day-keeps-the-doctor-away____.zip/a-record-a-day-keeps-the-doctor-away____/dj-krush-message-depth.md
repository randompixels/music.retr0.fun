---
title: "DJ Krush — 深層 (The Message At The Depth)"
date: 2017-05-20T21:59:47+00:00 
draft: false
year: "2002, Reissued in 2014"
artist: "DJ Krush"
album_name: "深層 (The Message At The Depth)"
format: "2xLP, Limited, Clear"
video: "A4h82SdBiG0"
cover: "/uploads/2017/05/IMG_9834-1.jpg"
images: ["/uploads/2017/05/FullSizeRender-8-1.jpg", "/uploads/2017/05/IMG_9835.jpg", "/uploads/2017/05/IMG_9836-1.jpg"]
---
