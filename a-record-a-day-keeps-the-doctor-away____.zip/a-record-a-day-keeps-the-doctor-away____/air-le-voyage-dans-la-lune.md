---
title: "Air — Le Voyage Dans La Lune"
date: 2019-06-11T14:54:44+00:00 
draft: false
year: "2012"
artist: "Air"
album_name: "Le Voyage Dans La Lune"
format: "LP + DVD, Limited Edition"
video: "osDyvfNQLrs"
cover: "/uploads/2019/06/IMG_7315-1024x1024.jpg"
images: ["/uploads/2019/06/IMG_7316.jpg", "/uploads/2019/06/IMG_7317.jpg", "/uploads/2019/06/IMG_7342.jpg", "/uploads/2019/06/IMG_7344.jpg"]
---
