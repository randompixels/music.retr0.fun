---
title: "Sfinx — Sfinx"
date: 2018-02-05T17:33:51+00:00 
draft: false
year: "1984"
artist: "Sfinx"
album_name: "Sfinx"
format: "LP"
video: "7S3OHMdflDc"
cover: "/uploads/2018/02/IMG_3009-1024x1024.jpg"
images: ["/uploads/2018/02/IMG_3010.jpg", "/uploads/2018/02/IMG_3008.jpg"]
---
