---
title: "Various Artists — T2: Trainspotting (Soundtrack)"
date: 2017-06-19T07:39:33+00:00 
draft: false
year: "2017"
artist: "Various Artists"
album_name: "T2: Trainspotting (Soundtrack)"
format: "2xLP, Gatefold"
video: "mEASmSwndnw"
cover: "/uploads/2017/06/IMG_0682-1024x1024.jpg"
images: ["/uploads/2017/06/IMG_0679.jpg", "/uploads/2017/06/IMG_0680-5.jpg", "/uploads/2017/06/IMG_0683.jpg"]
---
