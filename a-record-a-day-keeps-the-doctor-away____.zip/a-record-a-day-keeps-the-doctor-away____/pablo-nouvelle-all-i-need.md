---
title: "Pablo Nouvelle — All I Need"
date: 2019-06-23T19:03:13+03:00
lastmod: 2019-06-23T19:03:13+03:00
draft: false
year: "2016"
artist: "Pablo Nouvelle"
album_name: "All I Need"
format: "LP"
video: "ieHblDPikBY"
cover: "/uploads/2019/IMG_7590.JPG"
images: ['/uploads/2019/IMG_7591.JPG', '/uploads/2019/IMG_7629.JPG', '/uploads/2019/IMG_7630.JPG']
---
