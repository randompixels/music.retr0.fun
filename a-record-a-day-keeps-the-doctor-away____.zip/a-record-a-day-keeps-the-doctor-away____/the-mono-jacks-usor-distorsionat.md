---
title: "The Mono Jacks — Ușor Distorsionat"
date: 2019-02-13T11:59:23+00:00 
draft: false
year: "2017"
artist: "The Mono Jacks"
album_name: "Ușor Distorsionat"
format: "CD, Box"
video: "R00nymdAWhg"
cover: "/uploads/2019/02/IMG_3598.jpg"
images: ["/uploads/2019/02/IMG_3599.jpg", "/uploads/2019/02/IMG_3602.jpg", "/uploads/2019/02/IMG_3606.jpg", "/uploads/2019/02/IMG_3613.jpg", "/uploads/2019/02/IMG_3611-double.jpg", "/uploads/2019/02/IMG_3601.jpg", "/uploads/2019/02/IMG_3616.jpg"]
---
