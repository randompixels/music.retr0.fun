---
title: "Rezident Ex — Audio Doping"
date: 2019-01-22T08:48:21+00:00 
draft: false
year: "2017"
artist: "Rezident Ex"
album_name: "Audio Doping"
format: "LP"
video: "pl5N1X63oiA"
cover: "/uploads/2019/01/IMG_2608.jpg"
images: ["/uploads/2019/01/IMG_2609.jpg", "/uploads/2019/01/IMG_2651.jpg", "/uploads/2019/01/IMG_2650.jpg"]
---
