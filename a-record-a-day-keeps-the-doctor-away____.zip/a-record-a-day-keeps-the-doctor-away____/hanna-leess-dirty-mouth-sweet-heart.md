---
title: "Hanna Leess — Dirty Mouth Sweet Heart"
date: 2019-06-18T22:25:03+03:00
lastmod: 2019-06-18T22:25:03+03:00
draft: false
year: "2016"
artist: "Hanna Leess"
album_name: "Dirty Mouth Sweet Heart"
format: "LP"
video: "wyKs83pZzXc"
cover: "/uploads/2019/IMG_7353.JPG"
images: ['/uploads/2019/IMG_7355.JPG', '/uploads/2019/IMG_7356.JPG', '/uploads/2019/IMG_7357.JPG', '/uploads/2019/IMG_7358.JPG', '/uploads/2019/IMG_7359.JPG']
---
