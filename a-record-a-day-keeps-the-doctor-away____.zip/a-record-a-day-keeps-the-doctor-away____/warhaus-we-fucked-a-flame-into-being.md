---
title: "Warhaus — We Fucked A Flame Into Being"
date: 2019-06-09T11:06:06+00:00 
draft: false
year: "2016"
artist: "Warhaus"
album_name: "We Fucked A Flame Into Being"
format: "LP"
video: "vZs34P3iuRg"
cover: "/uploads/2019/06/IMG_7327.jpg"
images: ["/uploads/2019/06/IMG_7328.jpg", "/uploads/2019/06/IMG_7346.jpg", "/uploads/2019/06/IMG_7326.jpg", "/uploads/2019/06/IMG_7329.jpg", "/uploads/2019/06/IMG_7330.jpg"]
---
