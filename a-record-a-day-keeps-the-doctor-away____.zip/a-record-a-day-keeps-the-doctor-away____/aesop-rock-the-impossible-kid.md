---
title: "Aesop Rock — The Impossible Kid"
date: 2017-06-02T08:32:20+00:00 
draft: false
year: "2016"
artist: "Aesop Rock"
album_name: "The Impossible Kid"
format: "2xLP, Gatefold, Neon Green + Neon Pink "
video: "focgsmxHe5I"
cover: "/uploads/2017/06/IMG_0122-2-1024x1024.jpg"
images: ["/uploads/2017/06/IMG_0123-1.jpg", "/uploads/2017/06/IMG_0132-3.jpg", "/uploads/2017/06/IMG_0133.jpg", "/uploads/2017/06/IMG_0128.jpg", "/uploads/2017/06/IMG_0127-1.jpg", "/uploads/2017/06/IMG_0130.jpg", "/uploads/2017/06/IMG_0125.jpg", "/uploads/2017/06/IMG_0124.jpg", "/uploads/2017/06/IMG_0129.jpg"]
---
