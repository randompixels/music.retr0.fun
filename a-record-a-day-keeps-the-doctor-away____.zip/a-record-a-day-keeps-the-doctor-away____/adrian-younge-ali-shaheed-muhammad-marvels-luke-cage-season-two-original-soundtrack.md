---
title: "Adrian Younge & Ali Shaheed Muhammad — Marvel's Luke Cage - Season Two (Soundtrack)"
date: 2018-08-30T13:32:32+00:00 
draft: false
year: "2018"
artist: "Adrian Younge & Ali Shaheed Muhammad"
album_name: "Marvel's Luke Cage - Season Two (Soundtrack)"
format: "2xLP, Yellow [Smokey] "
video: ""
cover: "/uploads/2018/08/IMG_9095.jpg"
images: ["/uploads/2018/08/IMG_9093.jpg", "/uploads/2018/08/IMG_9096-1.jpg", "/uploads/2018/08/IMG_9099.jpg", "/uploads/2018/08/IMG_9094.jpg", "/uploads/2018/08/IMG_9097.jpg"]
---
