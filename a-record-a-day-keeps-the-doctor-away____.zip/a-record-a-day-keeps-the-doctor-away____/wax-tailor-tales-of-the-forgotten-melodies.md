---
title: "Wax Tailor – Tales of the Forgotten Melodies"
date: 2019-06-27T21:25:04+03:00
lastmod: 2019-06-27T21:25:04+03:00
draft: false
year: "2005 (Reissued 2015)"
artist: "Wax Tailor"
album_name: "Tales of the Forgotten Melodies"
format: "2xLP"
video: "2ACVtpokgU4"
cover: "/uploads/2019/IMG_7738.JPG"
images: ['/uploads/2019/IMG_7739.JPG', '/uploads/2019/IMG_7740.JPG', '/uploads/2019/IMG_7741.JPG']
---
