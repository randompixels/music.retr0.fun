---
title: "Wax Tailor – Hope & Sorrow"
date: 2019-06-28T11:36:34+03:00
lastmod: 2019-06-28T11:36:34+03:00
draft: false
year: "2005 (Reissued 2015)"
artist: "Wax Tailor"
album_name: "Hope & Sorrow"
format: "2xLP"
video: "YsAIx8g7y2Q"
cover: "/uploads/2019/IMG_7736.JPG"
images: ['/uploads/2019/IMG_7735.JPG', '/uploads/2019/IMG_7732.JPG', '/uploads/2019/IMG_7733.JPG']
---
