---
title: "Phil Collins — The Singles"
date: 2018-09-16T09:03:42+00:00 
draft: false
year: "2016"
artist: "Phil Collins"
album_name: "The Singles"
format: "4xLP, Compilation, Remastered "
video: "YkADj0TPrJA"
cover: "/uploads/2018/09/IMG_9703-1024x1024.jpg"
images: ["/uploads/2018/09/IMG_9701.jpg", "/uploads/2018/09/IMG_9702.jpg", "/uploads/2018/09/IMG_9706.jpg", "/uploads/2018/09/IMG_9710.jpg"]
---
