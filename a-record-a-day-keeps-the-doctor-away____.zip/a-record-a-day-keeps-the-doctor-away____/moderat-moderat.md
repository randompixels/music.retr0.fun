---
title: "Moderat — Moderat"
date: 2017-07-19T14:42:39+00:00 
draft: false
year: "2009"
artist: "Moderat"
album_name: "Moderat"
format: "LP, Gatefold"
video: "Dsdvv8LFrqY"
cover: "/uploads/2017/07/IMG_1256-1024x1024.jpg"
images: ["/uploads/2017/07/IMG_1257.jpg", "/uploads/2017/07/IMG_1259.jpg", "/uploads/2017/07/IMG_1258-1.jpg"]
---
