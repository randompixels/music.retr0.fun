---
title: "John Paesano — Marvel's Daredevil - Season One (Soundtrack)"
date: 2018-07-09T15:04:51+00:00 
draft: false
year: "2016"
artist: "John Paesano"
album_name: "Marvel's Daredevil - Season One (Soundtrack)"
format: "LP, Limited Edition to 3000, Red"
video: ""
cover: "/uploads/2018/07/IMG_7450.jpg"
images: ["/uploads/2018/07/IMG_7454.jpg", "/uploads/2018/07/IMG_7463.jpg", "/uploads/2018/07/IMG_7453.jpg", "/uploads/2018/07/IMG_7451.jpg"]
---
