---
title: "Moby — Play"
date: 2018-02-02T19:02:27+00:00 
draft: false
year: "1999 (Reissued 2016)"
artist: "Moby"
album_name: "Play"
format: "2xLP"
video: "8d9SgRtEkBo"
cover: "/uploads/2018/02/IMG_2938-1024x1024.jpg"
images: ["/uploads/2018/02/IMG_2939.jpg", "/uploads/2018/02/IMG_2937.jpg", "/uploads/2018/02/IMG_2940.jpg"]
---
