---
title: "Alex Turner — Submarine (Soundtrack)"
date: 2018-11-08T17:44:47+00:00 
draft: false
year: "2011"
artist: "Alex Turner"
album_name: "Submarine (Soundtrack)"
format: "EP, 10\""
video: "Ou1iMvB64oc"
cover: "/uploads/2018/11/IMG_1247.jpg"
images: ["/uploads/2018/11/IMG_1246-1.jpg", "/uploads/2018/11/IMG_1248.jpg", "/uploads/2018/11/IMG_1249.jpg"]
---
