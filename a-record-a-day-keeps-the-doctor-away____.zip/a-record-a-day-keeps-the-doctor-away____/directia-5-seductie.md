---
title: "Direcția 5 — Seducție"
date: 2018-02-08T10:29:15+00:00 
draft: false
year: "1993"
artist: "Direcția 5"
album_name: "Seducție"
format: "LP"
video: "wZ9t_bVeY_M"
cover: "/uploads/2018/02/IMG_3064-1024x1024.jpg"
images: ["/uploads/2018/02/IMG_3063.jpg", "/uploads/2018/02/IMG_3065.jpg", "/uploads/2018/02/IMG_3066.jpg"]
---
