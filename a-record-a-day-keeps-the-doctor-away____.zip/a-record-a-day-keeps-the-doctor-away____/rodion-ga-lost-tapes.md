---
title: "Rodion G.A. — The Lost Tapes"
date: 2017-04-27T21:32:56+00:00 
draft: false
year: "2013"
artist: "Rodion G.A."
album_name: "The Lost Tapes"
format: "2xLP, Gatefold"
video: "dkv0DkQWmUE"
cover: "/uploads/2017/04/IMG_9373-1024x1024.jpg"
images: ["/uploads/2017/04/IMG_9377.jpg", "/uploads/2017/04/IMG_9376.jpg", "/uploads/2017/04/IMG_9375-2.jpg"]
---
