---
title: "冨田勲 (Tomita Isao) — Switched On Hit & Rock"
date: 2018-04-29T17:17:28+00:00 
draft: false
year: "1972"
artist: "冨田勲 (Tomita Isao)"
album_name: "Switched On Hit & Rock"
format: "LP, Quadraphonic"
video: "OEyjEaXs3M8"
cover: "/uploads/2018/04/IMG_5190.jpg"
images: ["/uploads/2018/04/IMG_5194.jpg", "/uploads/2018/04/IMG_5189.jpg"]
---
