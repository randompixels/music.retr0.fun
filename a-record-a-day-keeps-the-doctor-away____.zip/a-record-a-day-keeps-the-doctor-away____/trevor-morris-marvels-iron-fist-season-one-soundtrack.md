---
title: "Trevor Morris — Marvel's Iron Fist - Season One (Soundtrack)"
date: 2018-07-12T11:21:08+00:00 
draft: false
year: "2017"
artist: "Trevor Morris"
album_name: "Marvel's Iron Fist - Season One (Soundtrack)"
format: "LP, Green"
video: ""
cover: "/uploads/2018/07/IMG_7440.jpg"
images: ["/uploads/2018/07/IMG_7444.jpg", "/uploads/2018/07/IMG_7465.jpg", "/uploads/2018/07/IMG_7443.jpg", "/uploads/2018/07/IMG_7441.jpg"]
---
