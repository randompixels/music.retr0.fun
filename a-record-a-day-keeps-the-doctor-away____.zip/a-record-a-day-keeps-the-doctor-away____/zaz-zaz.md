---
title: "ZAZ — ZAZ"
date: 2017-04-17T16:46:52+00:00 
draft: false
year: "2011"
artist: "ZAZ"
album_name: "ZAZ"
format: "LP"
video: "4l0ge5UnuuA"
cover: "/uploads/2017/04/IMG_9141-e1492445139976-1024x1024.jpg"
images: ["/uploads/2017/04/IMG_9142-1.jpg", "/uploads/2017/04/IMG_9144-1.jpg", "/uploads/2017/04/IMG_9143.jpg"]
---
