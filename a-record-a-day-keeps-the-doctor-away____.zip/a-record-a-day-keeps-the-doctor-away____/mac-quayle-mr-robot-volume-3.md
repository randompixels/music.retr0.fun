---
title: "Mac Quayle — Mr. Robot - Volume 3 (Soundtrack)"
date: 2018-01-17T18:30:18+00:00 
draft: false
year: "2017"
artist: "Mac Quayle"
album_name: "Mr. Robot - Volume 3 (Soundtrack)"
format: "2xLP, Clear w/ red & white splatter "
video: "T-dglvI2KXg"
cover: "/uploads/2018/01/IMG_2482-1024x1024.jpg"
images: ["/uploads/2018/01/IMG_2479.jpg", "/uploads/2018/01/IMG_2483.jpg", "/uploads/2018/01/IMG_2478.jpg"]
---
