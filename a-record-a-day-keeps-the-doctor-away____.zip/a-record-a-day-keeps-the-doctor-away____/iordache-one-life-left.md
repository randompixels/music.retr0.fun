---
title: "Iordache — One Life Left"
date: 2017-06-04T14:28:07+00:00 
draft: false
year: "2011"
artist: "Iordache"
album_name: "One Life Left"
format: "LP, Limited, Numbered"
video: "cIbJQUAuvpI"
cover: "/uploads/2017/06/IMG_0162-1024x1024.jpg"
images: ["/uploads/2017/06/IMG_0163-1.jpg", "/uploads/2017/06/IMG_0164.jpg"]
---
