---
title: "Jerry Goldsmith — Gremlins (Soundtrack)"
date: 2017-06-02T09:19:21+00:00 
draft: false
year: "2016"
artist: "Jerry Goldsmith"
album_name: "Gremlins (Soundtrack)"
format: "2xLP, Gatefold"
video: "2KQ1IwB3jNU"
cover: "/uploads/2017/06/IMG_0141-1-1024x1024.jpg"
images: ["/uploads/2017/06/IMG_0142.jpg", "/uploads/2017/06/IMG_0134.jpg", "/uploads/2017/06/IMG_0145.jpg", "/uploads/2017/06/IMG_0135.jpg", "/uploads/2017/06/IMG_0136.jpg", "/uploads/2017/06/IMG_0138.jpg", "/uploads/2017/06/IMG_0143-1.jpg", "/uploads/2017/06/IMG_0139.jpg", "/uploads/2017/06/IMG_0140-1.jpg"]
---
