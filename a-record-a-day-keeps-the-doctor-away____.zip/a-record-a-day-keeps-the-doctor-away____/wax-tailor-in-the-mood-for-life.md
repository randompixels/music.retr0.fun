---
title: "Wax Tailor — In the Mood for Life"
date: 2019-06-28T11:46:46+03:00
lastmod: 2019-06-28T11:46:46+03:00
draft: false
year: "2009 (Reissued 2015)\n2018 (Instrumental Version)"
artist: "Wax Tailor"
album_name: "In the Mood for Life (+Instrumental)"
format: "2xLP\n2xLP (Instrumental Version)"
video: "4jmIcPf72Ms", "TEI0DJxzKDE"
cover: "/uploads/2019/IMG_7744.jpg"
images: ['/uploads/2019/IMG_7699.JPG', '/uploads/2019/IMG_7700.JPG', '/uploads/2019/IMG_7676.JPG', '/uploads/2019/IMG_7698-wide.JPG', '/uploads/2019/IMG_7687.JPG', '/uploads/2019/IMG_7688.JPG', '/uploads/2019/IMG_7678.JPG']
---
