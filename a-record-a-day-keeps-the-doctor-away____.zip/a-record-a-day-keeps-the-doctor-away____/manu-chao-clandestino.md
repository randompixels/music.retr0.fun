---
title: "Manu Chao — Clandestino"
date: 2018-01-24T11:22:55+00:00 
draft: false
year: "1998 (Reissued 2013)"
artist: "Manu Chao"
album_name: "Clandestino"
format: "2xLP"
video: "rSEUH4KRfN8"
cover: "/uploads/2018/01/IMG_2640-1024x1024.jpg"
images: ["/uploads/2018/01/IMG_2639.jpg", "/uploads/2018/01/IMG_2641.jpg", "/uploads/2018/01/IMG_2642.jpg"]
---
