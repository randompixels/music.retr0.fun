---
title: "Mondial — Remember Mondial"
date: 2018-02-09T08:01:15+00:00 
draft: false
year: "1993"
artist: "Mondial"
album_name: "Remember Mondial"
format: "LP"
video: "NAsrpxxmzS0"
cover: "/uploads/2018/02/IMG_3079-1024x1024.jpg"
images: ["/uploads/2018/02/IMG_3076.jpg", "/uploads/2018/02/IMG_3080.jpg", "/uploads/2018/02/IMG_3077.jpg"]
---
