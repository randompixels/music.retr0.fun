---
title: "Goran Bregović — Welcome To Goran Bregović"
date: 2019-03-16T08:02:24+00:00 
draft: false
year: "2018"
artist: "Goran Bregović"
album_name: "Welcome To Goran Bregović"
format: "2xLP"
video: "2htSHzxVgQY"
cover: "/uploads/2019/03/IMG_4260.jpg"
images: ["/uploads/2019/03/IMG_4261.jpg", "/uploads/2019/03/IMG_4262.jpg", "/uploads/2019/03/IMG_4267.jpg", "/uploads/2019/03/IMG_4820.jpg", "/uploads/2019/03/IMG_4266.jpg", "/uploads/2019/03/IMG_4264.jpg"]
---
