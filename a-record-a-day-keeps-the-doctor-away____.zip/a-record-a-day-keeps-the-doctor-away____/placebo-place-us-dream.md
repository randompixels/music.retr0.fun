---
title: "Placebo — A Place For Us To Dream"
date: 2017-03-21T10:37:12+00:00 
draft: false
year: "2016"
artist: "Placebo"
album_name: "A Place For Us To Dream"
format: "4xLP, Boxset"
video: "4YR_Mft7yIM"
cover: "/uploads/2017/03/IMG_8299-3-e1490178765771-1024x1024.jpg"
images: ["/uploads/2017/03/IMG_8300-3.jpg", "/uploads/2017/03/IMG_8301-1.jpg", "/uploads/2017/03/IMG_8302.jpg"]
---
