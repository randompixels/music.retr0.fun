---
title: " Max Richter — Black Mirror: Nosedive (Soundtrack)"
date: 2019-06-05T12:46:37+00:00 
draft: false
year: "2017"
artist: " Max Richter"
album_name: "Black Mirror: Nosedive (Soundtrack)"
format: "LP"
video: "MQFJSgIF2kY"
cover: "/uploads/2019/06/IMG_7179.jpg"
images: ["/uploads/2019/06/IMG_7176.jpg", "/uploads/2019/06/IMG_7177.jpg", "/uploads/2019/06/IMG_7180.jpg"]
---
