---
title: "Gorillaz — Demon Days"
date: 2017-05-04T10:24:48+00:00 
draft: false
year: "2005"
artist: "Gorillaz"
album_name: "Demon Days"
format: "2LP, Gatefold, Limited, Red Translucent"
video: "hji4gBuOvIQ"
cover: "/uploads/2017/05/IMG_9529-2-1024x1024.jpg"
images: ["/uploads/2017/05/IMG_9532-1.jpg", "/uploads/2017/05/IMG_9531.jpg", "/uploads/2017/05/IMG_9533.jpg"]
---
