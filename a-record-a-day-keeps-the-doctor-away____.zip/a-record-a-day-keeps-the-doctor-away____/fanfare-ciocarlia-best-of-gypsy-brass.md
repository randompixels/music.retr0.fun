---
title: "Fanfare Ciocărlia — Best Of Gypsy Brass"
date: 2018-12-20T15:32:25+00:00 
draft: false
year: "2009"
artist: "Fanfare Ciocărlia"
album_name: "Best Of Gypsy Brass"
format: "LP"
video: "HRtnNrhpF_Y"
cover: "/uploads/2018/12/IMG_1629.jpg"
images: ["/uploads/2018/12/IMG_1631.jpg", "/uploads/2018/12/IMG_1630.jpg", "/uploads/2018/12/IMG_1645.jpg"]
---
