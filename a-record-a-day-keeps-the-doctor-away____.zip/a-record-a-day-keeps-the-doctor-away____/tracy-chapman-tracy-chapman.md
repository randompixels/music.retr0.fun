---
title: "Tracy Chapman — Tracy Chapman"
date: 2018-01-25T09:04:37+00:00 
draft: false
year: "1988"
artist: "Tracy Chapman"
album_name: "Tracy Chapman"
format: "LP"
video: "DwrHwZyFN7M"
cover: "/uploads/2018/01/IMG_2649-1024x1024.jpg"
images: ["/uploads/2018/01/IMG_2648.jpg", "/uploads/2018/01/IMG_2650.jpg", "/uploads/2018/01/IMG_2652.jpg"]
---
