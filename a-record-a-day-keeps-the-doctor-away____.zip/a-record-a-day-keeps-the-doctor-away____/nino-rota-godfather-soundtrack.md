---
title: "Nino Rota — Godfather (Soundtrack)"
date: 2018-01-20T13:54:35+00:00 
draft: false
year: "1972 (Reissued 2015)"
artist: "Nino Rota"
album_name: "Godfather (Soundtrack)"
format: "LP, Tri-gatefold sleeve"
video: "zMGE8pks9UE"
cover: "/uploads/2018/01/IMG_2540-1024x1024.jpg"
images: ["/uploads/2018/01/IMG_2539.jpg", "/uploads/2018/01/IMG_2541.jpg", "/uploads/2018/01/IMG_2542.jpg"]
---
