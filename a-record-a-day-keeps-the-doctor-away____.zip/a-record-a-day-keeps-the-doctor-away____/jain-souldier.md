---
title: "Jain — Souldier"
date: 2019-06-04T09:53:26+00:00 
draft: false
year: "2018"
artist: "Jain"
album_name: "Souldier"
format: "2xLP, Limited Edition, 45RPM, Red+Blue"
video: "MARsW26KXQg"
cover: "/uploads/2019/05/IMG_7073.jpg"
images: ["/uploads/2019/05/IMG_7075.jpg", "/uploads/2019/05/IMG_7077.jpg", "/uploads/2019/05/IMG_7074.jpg", "/uploads/2019/05/IMG_7048.jpg", "/uploads/2019/05/IMG_7049.jpg", "/uploads/2019/05/IMG_7050.jpg", "/uploads/2019/05/IMG_7042.jpg", "/uploads/2019/05/IMG_7041.jpg"]
---
