---
title: "Rammstein — Mutter"
date: 2018-05-04T14:58:05+00:00 
draft: false
year: "2001 (Reissued 2017)"
artist: "Rammstein"
album_name: "Mutter"
format: "2xLP"
video: "WXv31OmnKqQ"
cover: "/uploads/2018/05/IMG_5281.jpg"
images: ["/uploads/2018/05/IMG_5283.jpg", "/uploads/2018/05/IMG_5280.jpg", "/uploads/2018/05/IMG_5282.jpg"]
---
