---
title: "Various Artists — The Jungle Book (Soundtrack)"
date: 2017-04-19T11:42:15+00:00 
draft: false
year: "2016"
artist: "Various Artists"
album_name: "The Jungle Book (Soundtrack)"
format: "LP, Picture"
video: "9ogQ0uge06o"
cover: "/uploads/2017/04/IMG_9189-e1492602857316-1024x1024.jpg"
images: ["/uploads/2017/04/IMG_9188.jpg", "/uploads/2017/04/IMG_9190.jpg", "/uploads/2017/04/IMG_9185-2.gif"]
---
