---
title: "Arctic Monkeys — Tranquility Base Hotel + Casino"
date: 2018-09-24T15:05:06+00:00 
draft: false
year: "2018"
artist: "Arctic Monkeys"
album_name: "Tranquility Base Hotel + Casino"
format: "LP, Transparent"
video: "zKJrrMIsghI"
cover: "/uploads/2018/09/IMG_0021.jpg"
images: ["/uploads/2018/09/IMG_0028.jpg", "/uploads/2018/09/IMG_0023.jpg", "/uploads/2018/09/IMG_0025.jpg", "/uploads/2018/09/IMG_0027.jpg", "/uploads/2018/09/IMG_0022.jpg"]
---
