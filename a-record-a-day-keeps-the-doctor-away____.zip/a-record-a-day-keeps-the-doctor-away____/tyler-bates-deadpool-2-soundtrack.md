---
title: "Tyler Bates — Deadpool 2 (Soundtrack)"
date: 2018-11-04T16:31:07+00:00 
draft: false
year: "2018"
artist: "Tyler Bates"
album_name: "Deadpool 2 (Soundtrack)"
format: "LP, Picture"
video: "u0pt-hONuSA"
cover: "/uploads/2018/11/IMG_1143-1024x1024.jpg"
images: ["/uploads/2018/11/IMG_1144.jpg", "/uploads/2018/11/IMG_1145.jpg", "/uploads/2018/11/IMG_1146.jpg"]
---
