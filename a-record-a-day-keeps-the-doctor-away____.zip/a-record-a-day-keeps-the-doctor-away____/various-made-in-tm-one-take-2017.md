---
title: "Various — Made In TM - One Take 2017"
date: 2019-01-30T11:59:45+00:00 
draft: false
year: "2017"
artist: "Various"
album_name: "Made In TM - One Take 2017"
format: "LP"
video: "Zz9w5watx4c"
cover: "/uploads/2019/01/IMG_2887-1024x1024.jpg"
images: ["/uploads/2019/01/IMG_2888.jpg", "/uploads/2019/01/IMG_2893.jpg", "/uploads/2019/01/IMG_2896.jpg", "/uploads/2019/01/IMG_2889.jpg"]
---
