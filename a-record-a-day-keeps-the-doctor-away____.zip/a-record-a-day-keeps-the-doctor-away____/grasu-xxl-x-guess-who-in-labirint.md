---
title: "Grasu XXL x Guess Who — În Labirint"
date: 2018-10-25T14:35:05+00:00 
draft: false
year: "2018"
artist: "Grasu XXL x Guess Who"
album_name: "În Labirint"
format: "LP, Picture"
video: "KMxeqaPNTS0"
cover: "/uploads/2018/10/IMG_20181025_152517.jpg"
images: ["/uploads/2018/10/IMG_20181025_152541.jpg", "/uploads/2018/10/IMG_20181025_165821.jpg", "/uploads/2018/10/IMG_20181025_165801.jpg", "/uploads/2018/10/IMG_20181025_152643.jpg", "/uploads/2018/10/IMG_20181025_165738.jpg"]
---
