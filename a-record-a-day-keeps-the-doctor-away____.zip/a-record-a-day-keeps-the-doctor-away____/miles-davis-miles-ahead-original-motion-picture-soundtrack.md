---
title: "Miles Davis — Miles Ahead (Soundtrack)"
date: 2018-10-13T10:05:58+00:00 
draft: false
year: "2016"
artist: "Miles Davis"
album_name: "Miles Ahead (Soundtrack)"
format: "2xLP, Gatefold"
video: ""
cover: "/uploads/2018/10/IMG_0623.jpg"
images: ["/uploads/2018/10/IMG_0624.jpg", "/uploads/2018/10/IMG_0617.jpg", "/uploads/2018/10/IMG_0620.jpg"]
---
