---
title: "Johnny Cash — The Essential Johnny Cash"
date: 2017-04-28T12:26:08+00:00 
draft: false
year: "2015"
artist: "Johnny Cash"
album_name: "The Essential Johnny Cash"
format: "2xLP, Repress"
video: "Lq0fUa0vW_E"
cover: "/uploads/2017/04/IMG_9388-1024x1024.jpg"
images: ["/uploads/2017/04/IMG_9387.jpg", "/uploads/2017/04/IMG_9389.jpg", "/uploads/2017/04/IMG_9390.jpg"]
---
