---
title: "Karpov Not Kasparov – Soundtrack for a Game of Chess"
date: 2019-06-26T21:24:54+03:00
lastmod: 2019-06-26T21:24:54+03:00
draft: false
year: "2015"
artist: "Karpov Not Kasparov"
album_name: "Soundtrack for a Game of Chess"
format: "LP, Limited Edition, 25 handnumbered copies\nSilk-screen printed cover\n02/25"
video: "9SAd1nbbDdQ"
cover: "/uploads/2019/IMG_7415.JPG"
images: ['/uploads/2019/IMG_7416.JPG', '/uploads/2019/IMG_7417.JPG', '/uploads/2019/IMG_7441.JPG', '/uploads/2019/IMG_7442.JPG']
---
