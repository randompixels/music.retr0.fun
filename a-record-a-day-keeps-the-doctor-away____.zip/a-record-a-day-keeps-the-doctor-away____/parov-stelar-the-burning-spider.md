---
title: "Parov Stelar — The Burning Spider"
date: 2018-02-04T14:42:35+00:00 
draft: false
year: "2017"
artist: "Parov Stelar"
album_name: "The Burning Spider"
format: "2xLP, Limited Edition, Numbered, Hand-Painted, Signed "
video: ""
cover: "/uploads/2018/02/IMG_2967-1024x1024.jpg"
images: ["/uploads/2018/02/IMG_2983.jpg", "/uploads/2018/02/IMG_2987.jpg", "/uploads/2018/02/IMG_2965.jpg", "/uploads/2018/02/IMG_2984.jpg"]
---
