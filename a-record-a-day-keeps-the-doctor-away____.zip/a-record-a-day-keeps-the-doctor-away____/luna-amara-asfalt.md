---
title: "Luna Amară — Asfalt"
date: 2017-06-20T14:29:43+00:00 
draft: false
year: "2004"
artist: "Luna Amară"
album_name: "Asfalt"
format: "CD"
video: "dmixoQVndFk"
cover: "/uploads/2017/06/IMG_0703a-3-1024x1024.jpg"
images: ["/uploads/2017/06/IMG_0701.jpg", "/uploads/2017/06/IMG_0700.jpg", "/uploads/2017/06/IMG_0702.jpg"]
---
