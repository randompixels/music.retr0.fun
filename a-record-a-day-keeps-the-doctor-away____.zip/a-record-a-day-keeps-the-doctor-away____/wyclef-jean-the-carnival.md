---
title: "Wyclef Jean — The Carnival"
date: 2017-05-20T08:47:02+00:00 
draft: false
year: "1997, Reissued in 2016"
artist: "Wyclef Jean"
album_name: "The Carnival"
format: "2xLP, Limited, Blue/Purple Marbled"
video: "kI6MWZrl8v8"
cover: "/uploads/2017/05/IMG_9817-1024x1024.jpg"
images: ["/uploads/2017/05/IMG_9818.jpg", "/uploads/2017/05/IMG_9816.jpg", "/uploads/2017/05/IMG_9819-2.jpg"]
---
