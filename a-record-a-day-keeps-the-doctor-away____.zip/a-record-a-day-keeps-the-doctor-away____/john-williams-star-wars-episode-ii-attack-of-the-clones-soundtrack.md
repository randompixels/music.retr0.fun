---
title: "John Williams — Star Wars - Episode II: Attack Of The Clones (Soundtrack)"
date: 2018-03-29T12:56:43+00:00 
draft: false
year: "2002 (Reissued 2016)"
artist: "John Williams"
album_name: "Star Wars - Episode II: Attack Of The Clones (Soundtrack)"
format: "2xLP, Jango Fett colored vinyl (silver and royal blue), Limited - 1000"
video: "9nk_WHHTQtY"
cover: "/uploads/2018/03/IMG_4299.jpg"
images: ["/uploads/2018/03/IMG_4296.jpg", "/uploads/2018/03/IMG_4300.jpg", "/uploads/2018/03/IMG_4301.jpg"]
---
