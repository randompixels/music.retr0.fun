---
title: "Methadone Skies — Colosseus"
date: 2019-01-26T10:48:47+00:00 
draft: false
year: "2016"
artist: "Methadone Skies"
album_name: "Colosseus"
format: "LP, Green with white and blue splatter"
video: "H4EP-Ehh58A"
cover: "/uploads/2019/01/IMG_2787.jpg"
images: ["/uploads/2019/01/IMG_2788.jpg", "/uploads/2019/01/IMG_2786.jpg", "/uploads/2019/01/IMG_2790.jpg"]
---
