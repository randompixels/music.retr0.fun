---
title: "Various — Sucker Punch (Soundtrack)"
date: 2018-08-26T11:09:47+00:00 
draft: false
year: "2018"
artist: "Various"
album_name: "Sucker Punch (Soundtrack)"
format: "LP, Limited Edition of 1500, Numbered, 335, Translucent Green"
video: "zqbDaLRoPJ4"
cover: "/uploads/2018/08/IMG_9023.jpg"
images: ["/uploads/2018/08/IMG_9022.jpg", "/uploads/2018/08/IMG_9027.jpg", "/uploads/2018/08/IMG_9026.jpg", "/uploads/2018/08/IMG_9020.jpg", "/uploads/2018/08/IMG_9021.jpg", ""]
---
