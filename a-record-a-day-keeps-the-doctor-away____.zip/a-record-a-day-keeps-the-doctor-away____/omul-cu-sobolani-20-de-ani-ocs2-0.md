---
title: "Omul Cu Șobolani — 20 De Ani - OCS2.0"
date: 2017-06-13T12:34:29+00:00 
draft: false
year: "2017"
artist: "Omul Cu Șobolani"
album_name: "20 De Ani - OCS2.0"
format: "2xLP, Gatefold"
video: "uKWbJ4CApLE"
cover: "/uploads/2017/06/IMG_0622-1024x1024.jpg"
images: ["/uploads/2017/06/IMG_0623-2.jpg", "/uploads/2017/06/IMG_0625-3.jpg", "/uploads/2017/06/IMG_0624.jpg"]
---
