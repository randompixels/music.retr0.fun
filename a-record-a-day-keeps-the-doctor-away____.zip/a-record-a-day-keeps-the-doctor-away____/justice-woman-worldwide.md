---
title: "Justice — Woman Worldwide"
date: 2018-09-10T08:18:17+00:00 
draft: false
year: "2018"
artist: "Justice"
album_name: "Woman Worldwide"
format: "3xLP, 2xCD"
video: "otzcum1UKW4"
cover: "/uploads/2018/09/IMG_9480.jpg"
images: ["/uploads/2018/09/IMG_9482.jpg", "/uploads/2018/09/IMG_9481.jpg", "/uploads/2018/09/IMG_9476.jpg", "/uploads/2018/09/IMG_9484.jpg", "/uploads/2018/09/IMG_9477.jpg"]
---
