---
title: "John Williams — Star Wars - Episode IV: A New Hope (Soundtrack)"
date: 2018-03-31T09:35:11+00:00 
draft: false
year: "1977 (Reissued 2016)"
artist: "John Williams"
album_name: "Star Wars - Episode IV: A New Hope (Soundtrack)"
format: "2xLP, Gold"
video: "axZemDfcfX8"
cover: "/uploads/2018/03/IMG_4347.jpg"
images: ["/uploads/2018/03/IMG_4346.jpg", "/uploads/2018/03/IMG_4348.jpg", "/uploads/2018/03/IMG_4349.jpg", "/uploads/2018/03/IMG_4351.jpg", "/uploads/2018/03/IMG_4344.jpg", "/uploads/2018/03/IMG_4352.jpg"]
---
