---
title: "Cigarettes After Sex – Cigarettes After Sex"
date: 2019-06-23T12:01:08+03:00
lastmod: 2019-06-23T12:01:08+03:00
draft: false
year: "2017"
artist: "Cigarettes After Sex"
album_name: "Cigarettes After Sex"
format: "LP"
video: "sElE_BfQ67s"
cover: "/uploads/2019/IMG_7587.JPG"
images: ['/uploads/2019/IMG_7588.JPG', '/uploads/2019/IMG_7589.JPG', '/uploads/2019/IMG_7632.JPG', '/uploads/2019/IMG_7634.JPG']
---
