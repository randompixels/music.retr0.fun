---
title: "Seu Jorge — The Life Aquatic (Studio Sessions)"
date: 2019-05-13T03:49:52+00:00 
draft: false
year: "2014"
artist: "Seu Jorge"
album_name: "The Life Aquatic (Studio Sessions)"
format: "2xLP, Clear Translucid, Limited Edition, Unofficial"
video: "CVeD-xwJh-k"
cover: "/uploads/2019/05/IMG_6738-1024x1024.jpg"
images: ["/uploads/2019/05/IMG_6735.jpg", "/uploads/2019/05/IMG_6737.jpg", "/uploads/2019/05/IMG_6739.jpg"]
---
