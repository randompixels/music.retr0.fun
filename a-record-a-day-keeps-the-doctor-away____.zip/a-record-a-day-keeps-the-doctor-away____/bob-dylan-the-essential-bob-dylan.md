---
title: "Bob Dylan — The Essential Bob Dylan"
date: 2018-03-01T14:52:02+00:00 
draft: false
year: "2000 (Reissued 2016)"
artist: "Bob Dylan"
album_name: "The Essential Bob Dylan"
format: "2xLP"
video: "gazW7MOqHzQ"
cover: "/uploads/2018/03/IMG_3660-1024x1024.jpg"
images: ["/uploads/2018/03/IMG_3664.jpg", "/uploads/2018/03/IMG_3661.jpg", "/uploads/2018/03/IMG_3663.jpg", "/uploads/2018/03/IMG_3659.jpg"]
---
