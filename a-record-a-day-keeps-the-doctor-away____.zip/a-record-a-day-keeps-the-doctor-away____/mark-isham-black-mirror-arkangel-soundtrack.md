---
title: "Mark Isham — Black Mirror: Arkangel (Soundtrack)"
date: 2019-05-23T16:29:50+00:00 
draft: false
year: "2018"
artist: "Mark Isham"
album_name: "Black Mirror: Arkangel (Soundtrack)"
format: "LP, Limited Edition, Yellow"
video: "8NFsIIK8uic"
cover: "/uploads/2019/05/IMG_7028.jpg"
images: ["/uploads/2019/05/IMG_7030.jpg", "/uploads/2019/05/IMG_7026.jpg", "/uploads/2019/05/IMG_7025.jpg", "/uploads/2019/05/IMG_7023.jpg"]
---
