---
title: "The Last Shadow Puppets — Everything You've Come To Expect"
date: 2018-11-06T12:42:07+00:00 
draft: false
year: "2016"
artist: "The Last Shadow Puppets"
album_name: "Everything You've Come To Expect"
format: "LP + 7\", Limited Edition"
video: ""
cover: "/uploads/2018/11/IMG_1173.jpg"
images: ["/uploads/2018/11/IMG_1174.jpg", "/uploads/2018/11/IMG_1175.jpg", "/uploads/2018/11/IMG_1177.jpg", "/uploads/2018/11/IMG_1179.jpg", "/uploads/2018/11/IMG_1180.jpg", "/uploads/2018/11/IMG_1184.jpg", "/uploads/2018/11/IMG_1183.jpg", "/uploads/2018/11/IMG_1182.jpg"]
---
