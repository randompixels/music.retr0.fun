---
title: "Valeriu Sterian — Antirăzboinică"
date: 2017-05-02T18:47:04+00:00 
draft: false
year: "1979"
artist: "Valeriu Sterian"
album_name: "Antirăzboinică"
format: "LP"
video: "U8pydMbpZaEî"
cover: "/uploads/2017/05/IMG_9444-1024x1024.jpg"
images: ["/uploads/2017/05/IMG_9445.jpg", "/uploads/2017/05/IMG_9443.jpg"]
---
