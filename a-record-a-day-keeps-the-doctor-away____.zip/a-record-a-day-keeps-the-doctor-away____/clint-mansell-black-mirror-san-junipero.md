---
title: "Clint Mansell — Black Mirror: San Junipero (Soundtrack)"
date: 2018-01-16T13:52:59+00:00 
draft: false
year: "2017"
artist: "Clint Mansell"
album_name: "Black Mirror: San Junipero (Soundtrack)"
format: "LP, Turquoise"
video: "7R5lk6O8PQc"
cover: "/uploads/2018/01/IMG_2433-1024x1024.jpg"
images: ["/uploads/2018/01/IMG_2436.jpg", "/uploads/2018/01/IMG_2437.jpg", "/uploads/2018/01/IMG_2439.jpg"]
---
