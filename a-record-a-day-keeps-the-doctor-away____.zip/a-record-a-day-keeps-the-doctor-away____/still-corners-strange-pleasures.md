---
title: "Still Corners — Strange Pleasures"
date: 2019-06-07T09:21:11+00:00 
draft: false
year: "2013 (Reissued 2019)"
artist: "Still Corners"
album_name: "Strange Pleasures"
format: "LP. Limited Edition, Gold"
video: "V5YOhcAof8I"
cover: "/uploads/2019/06/IMG_7312.jpg"
images: ["/uploads/2019/06/IMG_7309.jpg", "/uploads/2019/06/IMG_7310.jpg", "/uploads/2019/06/IMG_7311.jpg", "/uploads/2019/06/IMG_7314.jpg"]
---
