---
title: "Justin Hurwitz — La La Land (Soundtrack)"
date: 2019-05-30T05:28:04+00:00 
draft: false
year: "2016"
artist: "Justin Hurwitz"
album_name: "La La Land (Soundtrack)"
format: "LP, Translucent Blue, Limited Edition"
video: "gk8C7ZxsJCU"
cover: "/uploads/2019/05/IMG_9564.jpg"
images: ["/uploads/2017/05/IMG_9568.jpg", "/uploads/2017/05/IMG_9567.jpg", "/uploads/2017/05/IMG_9566-1.jpg"]
---
