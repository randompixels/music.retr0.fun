---
title: "Netsky — 3"
date: 2017-03-28T09:12:15+00:00 
draft: false
year: "2016"
artist: "Netsky"
album_name: "3"
format: "2xLP"
video: "XZZWp8dKXpc"
cover: "/uploads/2017/03/IMG_8514-1024x1024.jpg"
images: ["/uploads/2017/03/IMG_8512.jpg", "/uploads/2017/03/IMG_8515.jpg", "/uploads/2017/03/IMG_8513.jpg"]
---
