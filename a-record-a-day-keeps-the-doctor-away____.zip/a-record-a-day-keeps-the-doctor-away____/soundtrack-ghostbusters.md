---
title: "Various Artists — Ghostbusters (Soundtrack)"
date: 2017-05-09T18:10:43+00:00 
draft: false
year: "2015"
artist: "Various Artists"
album_name: "Ghostbusters (Soundtrack)"
format: "LP, Red and White halves"
video: "m9We2XsVZfc"
cover: "/uploads/2017/05/IMG_9599-1024x1024.jpg"
images: ["/uploads/2017/05/IMG_9601.jpg", "/uploads/2017/05/IMG_9600.jpg", "/uploads/2017/05/IMG_9602-1.jpg"]
---
