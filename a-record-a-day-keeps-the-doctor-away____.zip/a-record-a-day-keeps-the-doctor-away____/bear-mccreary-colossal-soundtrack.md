---
title: "Bear McCreary — Colossal (Soundtrack)"
date: 2018-01-19T10:06:25+00:00 
draft: false
year: "2017"
artist: "Bear McCreary"
album_name: "Colossal (Soundtrack)"
format: "LP, Pink and Green Split "
video: "bzmQHhD45f8"
cover: "/uploads/2018/01/IMG_2509-1024x1024.jpg"
images: ["/uploads/2018/01/IMG_2505.jpg", "/uploads/2018/01/IMG_2510.jpg", "/uploads/2018/01/IMG_2508.jpg"]
---
