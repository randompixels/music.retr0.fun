---
title: "Hans Zimmer — Inception (Soundtrack)"
date: 2017-04-24T12:29:24+00:00 
draft: false
year: "2010"
artist: "Hans Zimmer"
album_name: "Inception (Soundtrack)"
format: "LP, Clear"
video: "RxabLA7UQ9k"
cover: "/uploads/2017/04/IMG_9299-1-1024x1024.jpg"
images: ["/uploads/2017/04/IMG_9298.jpg", "/uploads/2017/04/IMG_9297.jpg", "/uploads/2017/04/IMG_9296.jpg"]
---
