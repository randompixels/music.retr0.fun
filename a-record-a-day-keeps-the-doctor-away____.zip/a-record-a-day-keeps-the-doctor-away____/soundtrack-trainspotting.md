---
title: "Various Artists — Trainspotting (Soundtrack)"
date: 2017-06-19T07:11:20+00:00 
draft: false
year: "2016"
artist: "Various Artists"
album_name: "Trainspotting (Soundtrack)"
format: "2xLP, Orange"
video: "F_VbqvWRCkI"
cover: "/uploads/2017/06/IMG_0684-1024x1024.jpg"
images: ["/uploads/2017/06/IMG7526.jpg", "/uploads/2017/06/IMG_0685.jpg", "/uploads/2017/06/IMG_0686-1.jpg"]
---
