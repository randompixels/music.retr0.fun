---
title: "Various — BoJack Horseman (Soundtrack)"
date: 2019-03-22T13:46:23+00:00 
draft: false
year: "2017"
artist: "Various"
album_name: "BoJack Horseman (Soundtrack)"
format: "LP, Limited Edition, Picture Disc"
video: "_aKXMcyMTlY"
cover: "/uploads/2019/03/IMG_5008.jpg"
images: ["/uploads/2019/03/IMG_5015.jpg", "/uploads/2019/03/IMG_5013.jpg", "/uploads/2019/03/IMG_5010.jpg"]
---
