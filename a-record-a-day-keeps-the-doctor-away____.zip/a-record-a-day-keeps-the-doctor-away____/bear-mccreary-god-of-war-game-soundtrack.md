---
title: "Bear McCreary — God Of War (Game Soundtrack)"
date: 2018-10-01T08:40:51+00:00 
draft: false
year: "2018"
artist: "Bear McCreary"
album_name: "God Of War (Game Soundtrack)"
format: "2xLP, Bronze Translucent With Yellow Splatter + Blue & Light Blue Swirl With Clear Splatter "
video: "zoT2MgT2LVI"
cover: "/uploads/2018/09/IMG_0211-1024x1024.jpg"
images: ["/uploads/2018/09/IMG_0210.jpg", "/uploads/2018/09/IMG_0209.jpg", "/uploads/2018/09/IMG_0212.jpg", "/uploads/2018/09/IMG_0206.jpg", "/uploads/2018/09/IMG_0208.jpg"]
---
