---
title: "Santana — Supernatural"
date: 2017-03-23T13:57:18+00:00 
draft: false
year: "1999"
artist: "Santana"
album_name: "Supernatural"
format: "2xLP, Gatefold"
video: "6Whgn_iE5uc"
cover: "/uploads/2017/03/IMG_8334-e1490277502387-1024x1024.jpg"
images: ["/uploads/2017/03/FullSizeRender-4-1.jpg", "/uploads/2017/03/IMG_8347-e1490277792499.jpg", "/uploads/2017/03/FullSizeRender-3-1.jpg"]
---
