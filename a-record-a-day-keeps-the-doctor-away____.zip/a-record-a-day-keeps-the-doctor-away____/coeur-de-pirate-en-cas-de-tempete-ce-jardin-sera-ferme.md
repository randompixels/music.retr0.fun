---
title: "Cœur de pirate — en cas de tempête, ce jardin sera fermé."
date: 2019-01-13T11:12:12+00:00 
draft: false
year: "2018"
artist: "Cœur de pirate"
album_name: "en cas de tempête, ce jardin sera fermé."
format: "LP, Signed"
video: "IHB8rEqooCk"
cover: "/uploads/2019/01/IMG_2379.jpg"
images: ["/uploads/2019/01/IMG_2380.jpg", "/uploads/2019/01/IMG_2381.jpg", "/uploads/2019/01/IMG_2378.jpg"]
---
